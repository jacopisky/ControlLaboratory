/*
 * TestSimulinkConf.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TestSimulinkConf".
 *
 * Model version              : 1.1
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Apr 12 08:59:58 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "TestSimulinkConf.h"
#include "TestSimulinkConf_private.h"
#include "TestSimulinkConf_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCIe-6321", 4294967295U, 7, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_TestSimulinkConf_T TestSimulinkConf_B;

/* Block states (default storage) */
DW_TestSimulinkConf_T TestSimulinkConf_DW;

/* Real-time model */
static RT_MODEL_TestSimulinkConf_T TestSimulinkConf_M_;
RT_MODEL_TestSimulinkConf_T *const TestSimulinkConf_M = &TestSimulinkConf_M_;

/* Model output function */
void TestSimulinkConf_output(void)
{
  /* S-Function (sldrtai): '<Root>/Analog Input' */
  /* S-Function Block: <Root>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE) TestSimulinkConf_P.AnalogInput_RangeMode;
    parm.rangeidx = TestSimulinkConf_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2,
                   TestSimulinkConf_P.AnalogInput_Channels,
                   &TestSimulinkConf_B.AnalogInput[0], &parm);
  }

  /* S-Function (sldrtei): '<Root>/Encoder Input' */
  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter = TestSimulinkConf_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1,
                   &TestSimulinkConf_P.EncoderInput_Channels,
                   &TestSimulinkConf_B.EncoderInput, &parm);
  }

  /* S-Function (sldrtao): '<Root>/Analog Output' incorporates:
   *  Constant: '<Root>/Constant'
   */
  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) TestSimulinkConf_P.AnalogOutput_RangeMode;
      parm.rangeidx = TestSimulinkConf_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &TestSimulinkConf_P.AnalogOutput_Channels, ((real_T*)
        (&TestSimulinkConf_P.Constant_Value)), &parm);
    }
  }
}

/* Model update function */
void TestSimulinkConf_update(void)
{
  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++TestSimulinkConf_M->Timing.clockTick0)) {
    ++TestSimulinkConf_M->Timing.clockTickH0;
  }

  TestSimulinkConf_M->Timing.t[0] = TestSimulinkConf_M->Timing.clockTick0 *
    TestSimulinkConf_M->Timing.stepSize0 +
    TestSimulinkConf_M->Timing.clockTickH0 *
    TestSimulinkConf_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void TestSimulinkConf_initialize(void)
{
  /* Start for S-Function (sldrtao): '<Root>/Analog Output' incorporates:
   *  Constant: '<Root>/Constant'
   */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) TestSimulinkConf_P.AnalogOutput_RangeMode;
      parm.rangeidx = TestSimulinkConf_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &TestSimulinkConf_P.AnalogOutput_Channels,
                     &TestSimulinkConf_P.AnalogOutput_InitialValue, &parm);
    }
  }

  /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter = TestSimulinkConf_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1,
                   &TestSimulinkConf_P.EncoderInput_Channels, NULL, &parm);
  }
}

/* Model terminate function */
void TestSimulinkConf_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' incorporates:
   *  Constant: '<Root>/Constant'
   */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) TestSimulinkConf_P.AnalogOutput_RangeMode;
      parm.rangeidx = TestSimulinkConf_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &TestSimulinkConf_P.AnalogOutput_Channels,
                     &TestSimulinkConf_P.AnalogOutput_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  TestSimulinkConf_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  TestSimulinkConf_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  TestSimulinkConf_initialize();
}

void MdlTerminate(void)
{
  TestSimulinkConf_terminate();
}

/* Registration function */
RT_MODEL_TestSimulinkConf_T *TestSimulinkConf(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  TestSimulinkConf_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)TestSimulinkConf_M, 0,
                sizeof(RT_MODEL_TestSimulinkConf_T));

  /* Initialize timing info */
  {
    int_T *mdlTsMap = TestSimulinkConf_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    TestSimulinkConf_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    TestSimulinkConf_M->Timing.sampleTimes =
      (&TestSimulinkConf_M->Timing.sampleTimesArray[0]);
    TestSimulinkConf_M->Timing.offsetTimes =
      (&TestSimulinkConf_M->Timing.offsetTimesArray[0]);

    /* task periods */
    TestSimulinkConf_M->Timing.sampleTimes[0] = (0.001);

    /* task offsets */
    TestSimulinkConf_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(TestSimulinkConf_M, &TestSimulinkConf_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = TestSimulinkConf_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    TestSimulinkConf_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(TestSimulinkConf_M, -1);
  TestSimulinkConf_M->Timing.stepSize0 = 0.001;

  /* External mode info */
  TestSimulinkConf_M->Sizes.checksums[0] = (2667777081U);
  TestSimulinkConf_M->Sizes.checksums[1] = (2861219259U);
  TestSimulinkConf_M->Sizes.checksums[2] = (657115720U);
  TestSimulinkConf_M->Sizes.checksums[3] = (1992204255U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    TestSimulinkConf_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(TestSimulinkConf_M->extModeInfo,
      &TestSimulinkConf_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(TestSimulinkConf_M->extModeInfo,
                        TestSimulinkConf_M->Sizes.checksums);
    rteiSetTPtr(TestSimulinkConf_M->extModeInfo, rtmGetTPtr(TestSimulinkConf_M));
  }

  TestSimulinkConf_M->solverInfoPtr = (&TestSimulinkConf_M->solverInfo);
  TestSimulinkConf_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&TestSimulinkConf_M->solverInfo, 0.001);
  rtsiSetSolverMode(&TestSimulinkConf_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  TestSimulinkConf_M->blockIO = ((void *) &TestSimulinkConf_B);
  (void) memset(((void *) &TestSimulinkConf_B), 0,
                sizeof(B_TestSimulinkConf_T));

  /* parameters */
  TestSimulinkConf_M->defaultParam = ((real_T *)&TestSimulinkConf_P);

  /* states (dwork) */
  TestSimulinkConf_M->dwork = ((void *) &TestSimulinkConf_DW);
  (void) memset((void *)&TestSimulinkConf_DW, 0,
                sizeof(DW_TestSimulinkConf_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    TestSimulinkConf_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  TestSimulinkConf_M->Sizes.numContStates = (0);/* Number of continuous states */
  TestSimulinkConf_M->Sizes.numY = (0);/* Number of model outputs */
  TestSimulinkConf_M->Sizes.numU = (0);/* Number of model inputs */
  TestSimulinkConf_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  TestSimulinkConf_M->Sizes.numSampTimes = (1);/* Number of sample times */
  TestSimulinkConf_M->Sizes.numBlocks = (6);/* Number of blocks */
  TestSimulinkConf_M->Sizes.numBlockIO = (2);/* Number of block outputs */
  TestSimulinkConf_M->Sizes.numBlockPrms = (18);/* Sum of parameter "widths" */
  return TestSimulinkConf_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
