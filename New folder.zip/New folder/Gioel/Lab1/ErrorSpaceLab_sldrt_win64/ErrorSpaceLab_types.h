/*
 * ErrorSpaceLab_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ErrorSpaceLab".
 *
 * Model version              : 1.9
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Apr 12 11:14:04 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ErrorSpaceLab_types_h_
#define RTW_HEADER_ErrorSpaceLab_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_struct_maRdsT552Ssb6DCvBQFJUB_
#define DEFINED_TYPEDEF_FOR_struct_maRdsT552Ssb6DCvBQFJUB_

typedef struct {
  real_T Tr1;
  real_T Tr2;
  real_T Tr3;
  real_T Tr4;
  real_T w1;
  real_T w2;
  real_T w3;
  real_T w4;
  real_T A11_1[9];
  real_T A12_1[6];
  real_T A21_1[6];
  real_T A22_1[4];
  real_T Az_1[25];
  real_T A11_2[9];
  real_T A12_2[6];
  real_T A21_2[6];
  real_T A22_2[4];
  real_T Az_2[25];
  real_T A11_3[9];
  real_T A12_3[6];
  real_T A21_3[6];
  real_T A22_3[4];
  real_T Az_3[25];
  real_T A11_4[9];
  real_T A12_4[6];
  real_T A21_4[6];
  real_T A22_4[4];
  real_T Az_4[25];
  real_T Bz[5];
  creal_T p1;
  creal_T p2;
  creal_T p3;
  creal_T p4;
  real_T p5;
  creal_T eigs[5];
  real_T Kz_1[5];
  real_T Kpsi_1[2];
  real_T Hnum_1[3];
  real_T Hden_1[4];
  real_T Kz_2[5];
  real_T Kpsi_2[2];
  real_T Hnum_2[3];
  real_T Kz_3[5];
  real_T Kpsi_3[2];
  real_T Hnum_3[3];
  real_T Hden_3[4];
  real_T Kz_4[5];
  real_T Kpsi_4[2];
  real_T Hnum_4[3];
  real_T Hden_4[4];
  real_T t[5899];
  real_T thl_nsf[5899];
  real_T thl_sf[5899];
  real_T thl_Ref[5899];
  real_T err_thl_nsf_w3[30393];
  real_T err_thl_nsf_01[30393];
  real_T err_thl_sf_w3[30624];
  real_T err_thl_sf_01[30624];
} struct_maRdsT552Ssb6DCvBQFJUB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_
#define DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_

typedef struct {
  real_T Rs;
} struct_vHPMdAr9HfDgWNbG6U3SfC;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_
#define DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_

typedef struct {
  real_T ppr;
  real_T pulse2deg;
  real_T pulse2rad;
  real_T deg2pulse;
  real_T rad2pulse;
  real_T T_s;
  real_T q;
} struct_L7PNJsBgXqfoUC1iyFkLDE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_
#define DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_

typedef struct {
  real_T R;
  real_T V;
  real_T th_deg;
  real_T th;
} struct_DqRrFctOcoTwJhkxMXTGZG;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_
#define DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_

typedef struct {
  struct_DqRrFctOcoTwJhkxMXTGZG range;
  real_T deg2V;
  real_T rad2V;
  real_T V2deg;
  real_T V2rad;
} struct_t4jfYKvXkqvqbOrnXV9flF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_coKXDsi5RvH3V98DgL1TfD_
#define DEFINED_TYPEDEF_FOR_struct_coKXDsi5RvH3V98DgL1TfD_

typedef struct {
  struct_vHPMdAr9HfDgWNbG6U3SfC curr;
  struct_L7PNJsBgXqfoUC1iyFkLDE enc;
  struct_t4jfYKvXkqvqbOrnXV9flF pot1;
} struct_coKXDsi5RvH3V98DgL1TfD;

#endif

/* Parameters (default storage) */
typedef struct P_ErrorSpaceLab_T_ P_ErrorSpaceLab_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_ErrorSpaceLab_T RT_MODEL_ErrorSpaceLab_T;

#endif                                 /* RTW_HEADER_ErrorSpaceLab_types_h_ */
