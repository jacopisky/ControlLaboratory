/*
 * Extendedlab_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Extendedlab".
 *
 * Model version              : 1.13
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Apr 12 11:49:12 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Extendedlab_types_h_
#define RTW_HEADER_Extendedlab_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_struct_6KBw5lFOe4lH3pUr4DNx3C_
#define DEFINED_TYPEDEF_FOR_struct_6KBw5lFOe4lH3pUr4DNx3C_

typedef struct {
  real_T Ae11_1[9];
  real_T Ae12_1[6];
  real_T Ae21_1[6];
  real_T Ae22_1[4];
  real_T Ae_1[25];
  real_T Ae11_2[9];
  real_T Ae12_2[6];
  real_T Ae21_2[6];
  real_T Ae22_2[4];
  real_T Ae_2[25];
  real_T Ae11_3[9];
  real_T Ae12_3[6];
  real_T Ae21_3[6];
  real_T Ae22_3[4];
  real_T Ae_3[25];
  real_T Ae11_4[9];
  real_T Ae12_4[6];
  real_T Ae21_4[6];
  real_T Ae22_4[4];
  real_T Ae_4[25];
  real_T Be[5];
  real_T Ce[5];
  creal_T e1;
  creal_T e2;
  creal_T e3;
  creal_T e4;
  real_T e5;
  creal_T e_eigs[5];
  creal_T c1;
  creal_T c2;
  creal_T c_eigs[2];
  real_T Le_1[5];
  real_T Le_2[5];
  real_T Le_3[5];
  real_T Le_4[5];
  real_T K[2];
  real_T t[5630];
  real_T thl_nsf[5630];
  real_T thl_sf[5630];
  real_T thl_Ref[5630];
  real_T err_t[5901];
  real_T err_thl_nsf_w3[5901];
  real_T err_thl_nsf_01[5901];
} struct_6KBw5lFOe4lH3pUr4DNx3C;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_
#define DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_

typedef struct {
  real_T Rs;
} struct_vHPMdAr9HfDgWNbG6U3SfC;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_
#define DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_

typedef struct {
  real_T ppr;
  real_T pulse2deg;
  real_T pulse2rad;
  real_T deg2pulse;
  real_T rad2pulse;
  real_T T_s;
  real_T q;
} struct_L7PNJsBgXqfoUC1iyFkLDE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_
#define DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_

typedef struct {
  real_T R;
  real_T V;
  real_T th_deg;
  real_T th;
} struct_DqRrFctOcoTwJhkxMXTGZG;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_
#define DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_

typedef struct {
  struct_DqRrFctOcoTwJhkxMXTGZG range;
  real_T deg2V;
  real_T rad2V;
  real_T V2deg;
  real_T V2rad;
} struct_t4jfYKvXkqvqbOrnXV9flF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_coKXDsi5RvH3V98DgL1TfD_
#define DEFINED_TYPEDEF_FOR_struct_coKXDsi5RvH3V98DgL1TfD_

typedef struct {
  struct_vHPMdAr9HfDgWNbG6U3SfC curr;
  struct_L7PNJsBgXqfoUC1iyFkLDE enc;
  struct_t4jfYKvXkqvqbOrnXV9flF pot1;
} struct_coKXDsi5RvH3V98DgL1TfD;

#endif

/* Parameters (default storage) */
typedef struct P_Extendedlab_T_ P_Extendedlab_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Extendedlab_T RT_MODEL_Extendedlab_T;

#endif                                 /* RTW_HEADER_Extendedlab_types_h_ */
