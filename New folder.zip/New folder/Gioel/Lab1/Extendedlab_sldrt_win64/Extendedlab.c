/*
 * Extendedlab.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Extendedlab".
 *
 * Model version              : 1.13
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Apr 12 11:49:12 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Extendedlab.h"
#include "Extendedlab_private.h"
#include "Extendedlab_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
  0.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCIe-6321", 4294967295U, 7, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_Extendedlab_T Extendedlab_B;

/* Continuous states */
X_Extendedlab_T Extendedlab_X;

/* Block states (default storage) */
DW_Extendedlab_T Extendedlab_DW;

/* Real-time model */
static RT_MODEL_Extendedlab_T Extendedlab_M_;
RT_MODEL_Extendedlab_T *const Extendedlab_M = &Extendedlab_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 5;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Extendedlab_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  Extendedlab_output();
  Extendedlab_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  Extendedlab_output();
  Extendedlab_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void Extendedlab_output(void)
{
  real_T rtb_FullOrderObserver1[5];
  real_T rtb_Sum2;
  int_T ci;
  int_T iy;
  if (rtmIsMajorTimeStep(Extendedlab_M)) {
    /* set solver stop time */
    if (!(Extendedlab_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&Extendedlab_M->solverInfo,
                            ((Extendedlab_M->Timing.clockTickH0 + 1) *
        Extendedlab_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&Extendedlab_M->solverInfo,
                            ((Extendedlab_M->Timing.clockTick0 + 1) *
        Extendedlab_M->Timing.stepSize0 + Extendedlab_M->Timing.clockTickH0 *
        Extendedlab_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Extendedlab_M)) {
    Extendedlab_M->Timing.t[0] = rtsiGetT(&Extendedlab_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(Extendedlab_M)) {
    /* S-Function (sldrtai): '<Root>/Analog Input' */
    /* S-Function Block: <Root>/Analog Input */
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) Extendedlab_P.AnalogInput_RangeMode;
      parm.rangeidx = Extendedlab_P.AnalogInput_VoltRange;
      RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2,
                     Extendedlab_P.AnalogInput_Channels,
                     &Extendedlab_B.AnalogInput[0], &parm);
    }

    /* S-Function (sldrtei): '<Root>/Encoder Input' */
    /* S-Function Block: <Root>/Encoder Input */
    {
      ENCODERINPARM parm;
      parm.quad = (QUADMODE) 2;
      parm.index = (INDEXPULSE) 0;
      parm.infilter = Extendedlab_P.EncoderInput_InputFilter;
      RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1,
                     &Extendedlab_P.EncoderInput_Channels, &Extendedlab_B.thlt,
                     &parm);
    }
  }

  /* StateSpace: '<Root>/Full Order Observer1' */
  for (iy = 0; iy < 5; iy++) {
    rtb_FullOrderObserver1[iy] = 0.0;
  }

  for (ci = 0; ci < 5; ci++) {
    for (iy = 0; iy < 5; iy++) {
      rtb_FullOrderObserver1[iy] += Extendedlab_P.FullOrderObserver1_C[ci * 5 +
        iy] * Extendedlab_X.FullOrderObserver1_CSTATE[ci];
    }
  }

  /* End of StateSpace: '<Root>/Full Order Observer1' */

  /* Sum: '<Root>/Sum3' incorporates:
   *  Gain: '<Root>/C_rho'
   *  Gain: '<Root>/K'
   */
  Extendedlab_B.Sum3 = (0.0 - (Extendedlab_P.ss_est.K[0] *
    rtb_FullOrderObserver1[3] + Extendedlab_P.ss_est.K[1] *
    rtb_FullOrderObserver1[4])) - ((Extendedlab_P.C_rho_Gain[0] *
    rtb_FullOrderObserver1[0] + Extendedlab_P.C_rho_Gain[1] *
    rtb_FullOrderObserver1[1]) + Extendedlab_P.C_rho_Gain[2] *
    rtb_FullOrderObserver1[2]);
  if (rtmIsMajorTimeStep(Extendedlab_M)) {
    /* S-Function (sldrtao): '<Root>/Analog Output' */
    /* S-Function Block: <Root>/Analog Output */
    {
      {
        ANALOGIOPARM parm;
        parm.mode = (RANGEMODE) Extendedlab_P.AnalogOutput_RangeMode;
        parm.rangeidx = Extendedlab_P.AnalogOutput_VoltRange;
        RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                       &Extendedlab_P.AnalogOutput_Channels, ((real_T*)
          (&Extendedlab_B.Sum3)), &parm);
      }
    }

    /* Gain: '<Root>/pulse2deg2' */
    Extendedlab_B.pulse2deg2 = Extendedlab_P.sens.enc.pulse2deg *
      Extendedlab_B.thlt;
  }

  /* ManualSwitch: '<Root>/switch1' incorporates:
   *  Step: '<Root>/step1'
   */
  if (Extendedlab_P.switch1_CurrentSetting == 1) {
    /* ManualSwitch: '<Root>/switch1' incorporates:
     *  Sin: '<Root>/sine1'
     */
    Extendedlab_B.switch1 = sin(Extendedlab_P.sine1_Freq *
      Extendedlab_M->Timing.t[0] + Extendedlab_P.sine1_Phase) *
      Extendedlab_P.sine1_Amp + Extendedlab_P.sine1_Bias;
  } else if (Extendedlab_M->Timing.t[0] < Extendedlab_P.step1_Time) {
    /* Step: '<Root>/step1' incorporates:
     *  ManualSwitch: '<Root>/switch1'
     */
    Extendedlab_B.switch1 = Extendedlab_P.step1_Y0;
  } else {
    /* ManualSwitch: '<Root>/switch1' incorporates:
     *  Step: '<Root>/step1'
     */
    Extendedlab_B.switch1 = Extendedlab_P.step1_YFinal;
  }

  /* End of ManualSwitch: '<Root>/switch1' */
  if (rtmIsMajorTimeStep(Extendedlab_M)) {
  }

  /* Sum: '<Root>/Sum2' */
  rtb_Sum2 = Extendedlab_B.pulse2deg2 - Extendedlab_B.switch1;

  /* Gain: '<Root>/Gain' */
  Extendedlab_B.Gain = Extendedlab_P.Gain_Gain * rtb_Sum2;
  if (rtmIsMajorTimeStep(Extendedlab_M)) {
  }

  /* SignalConversion generated from: '<Root>/Full Order Observer1' incorporates:
   *  Gain: '<Root>/pulse2deg3'
   */
  Extendedlab_B.TmpSignalConversionAtFullOrderObserver1Inport1[0] =
    Extendedlab_B.Sum3;
  Extendedlab_B.TmpSignalConversionAtFullOrderObserver1Inport1[1] =
    Extendedlab_P.deg2rad * rtb_Sum2;
}

/* Model update function */
void Extendedlab_update(void)
{
  if (rtmIsMajorTimeStep(Extendedlab_M)) {
    rt_ertODEUpdateContinuousStates(&Extendedlab_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Extendedlab_M->Timing.clockTick0)) {
    ++Extendedlab_M->Timing.clockTickH0;
  }

  Extendedlab_M->Timing.t[0] = rtsiGetSolverStopTime(&Extendedlab_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++Extendedlab_M->Timing.clockTick1)) {
      ++Extendedlab_M->Timing.clockTickH1;
    }

    Extendedlab_M->Timing.t[1] = Extendedlab_M->Timing.clockTick1 *
      Extendedlab_M->Timing.stepSize1 + Extendedlab_M->Timing.clockTickH1 *
      Extendedlab_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void Extendedlab_derivatives(void)
{
  XDot_Extendedlab_T *_rtXdot;
  int_T FullOrderObserver1_CSTATE_tmp;
  int_T ci;
  int_T is;
  _rtXdot = ((XDot_Extendedlab_T *) Extendedlab_M->derivs);

  /* Derivatives for StateSpace: '<Root>/Full Order Observer1' */
  for (is = 0; is < 5; is++) {
    _rtXdot->FullOrderObserver1_CSTATE[is] = 0.0;
  }

  for (ci = 0; ci < 5; ci++) {
    for (is = 0; is < 5; is++) {
      FullOrderObserver1_CSTATE_tmp = ci * 5 + is;
      _rtXdot->FullOrderObserver1_CSTATE[is] +=
        (Extendedlab_P.ss_est.Ae_3[FullOrderObserver1_CSTATE_tmp] -
         Extendedlab_ConstP.FullOrderObserver1_rtw_collapsed_sub_expr_11[FullOrderObserver1_CSTATE_tmp])
        * Extendedlab_X.FullOrderObserver1_CSTATE[ci];
    }
  }

  for (ci = 0; ci < 2; ci++) {
    for (is = 0; is < 5; is++) {
      _rtXdot->FullOrderObserver1_CSTATE[is] +=
        Extendedlab_P.FullOrderObserver1_B[ci * 5 + is] *
        Extendedlab_B.TmpSignalConversionAtFullOrderObserver1Inport1[ci];
    }
  }

  /* End of Derivatives for StateSpace: '<Root>/Full Order Observer1' */
}

/* Model initialize function */
void Extendedlab_initialize(void)
{
  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) Extendedlab_P.AnalogOutput_RangeMode;
      parm.rangeidx = Extendedlab_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &Extendedlab_P.AnalogOutput_Channels,
                     &Extendedlab_P.AnalogOutput_InitialValue, &parm);
    }
  }

  {
    int_T is;

    /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

    /* S-Function Block: <Root>/Encoder Input */
    {
      ENCODERINPARM parm;
      parm.quad = (QUADMODE) 2;
      parm.index = (INDEXPULSE) 0;
      parm.infilter = Extendedlab_P.EncoderInput_InputFilter;
      RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1,
                     &Extendedlab_P.EncoderInput_Channels, NULL, &parm);
    }

    /* InitializeConditions for StateSpace: '<Root>/Full Order Observer1' */
    for (is = 0; is < 5; is++) {
      Extendedlab_X.FullOrderObserver1_CSTATE[is] =
        Extendedlab_P.FullOrderObserver1_InitialCondition;
    }

    /* End of InitializeConditions for StateSpace: '<Root>/Full Order Observer1' */
  }
}

/* Model terminate function */
void Extendedlab_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) Extendedlab_P.AnalogOutput_RangeMode;
      parm.rangeidx = Extendedlab_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &Extendedlab_P.AnalogOutput_Channels,
                     &Extendedlab_P.AnalogOutput_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  Extendedlab_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  Extendedlab_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Extendedlab_initialize();
}

void MdlTerminate(void)
{
  Extendedlab_terminate();
}

/* Registration function */
RT_MODEL_Extendedlab_T *Extendedlab(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  Extendedlab_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)Extendedlab_M, 0,
                sizeof(RT_MODEL_Extendedlab_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Extendedlab_M->solverInfo,
                          &Extendedlab_M->Timing.simTimeStep);
    rtsiSetTPtr(&Extendedlab_M->solverInfo, &rtmGetTPtr(Extendedlab_M));
    rtsiSetStepSizePtr(&Extendedlab_M->solverInfo,
                       &Extendedlab_M->Timing.stepSize0);
    rtsiSetdXPtr(&Extendedlab_M->solverInfo, &Extendedlab_M->derivs);
    rtsiSetContStatesPtr(&Extendedlab_M->solverInfo, (real_T **)
                         &Extendedlab_M->contStates);
    rtsiSetNumContStatesPtr(&Extendedlab_M->solverInfo,
      &Extendedlab_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&Extendedlab_M->solverInfo,
      &Extendedlab_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&Extendedlab_M->solverInfo,
      &Extendedlab_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&Extendedlab_M->solverInfo,
      &Extendedlab_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&Extendedlab_M->solverInfo, (&rtmGetErrorStatus
      (Extendedlab_M)));
    rtsiSetRTModelPtr(&Extendedlab_M->solverInfo, Extendedlab_M);
  }

  rtsiSetSimTimeStep(&Extendedlab_M->solverInfo, MAJOR_TIME_STEP);
  Extendedlab_M->intgData.y = Extendedlab_M->odeY;
  Extendedlab_M->intgData.f[0] = Extendedlab_M->odeF[0];
  Extendedlab_M->intgData.f[1] = Extendedlab_M->odeF[1];
  Extendedlab_M->intgData.f[2] = Extendedlab_M->odeF[2];
  Extendedlab_M->contStates = ((real_T *) &Extendedlab_X);
  rtsiSetSolverData(&Extendedlab_M->solverInfo, (void *)&Extendedlab_M->intgData);
  rtsiSetSolverName(&Extendedlab_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Extendedlab_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    Extendedlab_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Extendedlab_M->Timing.sampleTimes = (&Extendedlab_M->
      Timing.sampleTimesArray[0]);
    Extendedlab_M->Timing.offsetTimes = (&Extendedlab_M->
      Timing.offsetTimesArray[0]);

    /* task periods */
    Extendedlab_M->Timing.sampleTimes[0] = (0.0);
    Extendedlab_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    Extendedlab_M->Timing.offsetTimes[0] = (0.0);
    Extendedlab_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(Extendedlab_M, &Extendedlab_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Extendedlab_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    Extendedlab_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Extendedlab_M, 10.0);
  Extendedlab_M->Timing.stepSize0 = 0.001;
  Extendedlab_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  Extendedlab_M->Sizes.checksums[0] = (2365051867U);
  Extendedlab_M->Sizes.checksums[1] = (2215242662U);
  Extendedlab_M->Sizes.checksums[2] = (3235105363U);
  Extendedlab_M->Sizes.checksums[3] = (1285303616U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    Extendedlab_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(Extendedlab_M->extModeInfo,
      &Extendedlab_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Extendedlab_M->extModeInfo,
                        Extendedlab_M->Sizes.checksums);
    rteiSetTPtr(Extendedlab_M->extModeInfo, rtmGetTPtr(Extendedlab_M));
  }

  Extendedlab_M->solverInfoPtr = (&Extendedlab_M->solverInfo);
  Extendedlab_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&Extendedlab_M->solverInfo, 0.001);
  rtsiSetSolverMode(&Extendedlab_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  Extendedlab_M->blockIO = ((void *) &Extendedlab_B);
  (void) memset(((void *) &Extendedlab_B), 0,
                sizeof(B_Extendedlab_T));

  /* parameters */
  Extendedlab_M->defaultParam = ((real_T *)&Extendedlab_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &Extendedlab_X;
    Extendedlab_M->contStates = (x);
    (void) memset((void *)&Extendedlab_X, 0,
                  sizeof(X_Extendedlab_T));
  }

  /* states (dwork) */
  Extendedlab_M->dwork = ((void *) &Extendedlab_DW);
  (void) memset((void *)&Extendedlab_DW, 0,
                sizeof(DW_Extendedlab_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    Extendedlab_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 20;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  Extendedlab_M->Sizes.numContStates = (5);/* Number of continuous states */
  Extendedlab_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  Extendedlab_M->Sizes.numY = (0);     /* Number of model outputs */
  Extendedlab_M->Sizes.numU = (0);     /* Number of model inputs */
  Extendedlab_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  Extendedlab_M->Sizes.numSampTimes = (2);/* Number of sample times */
  Extendedlab_M->Sizes.numBlocks = (19);/* Number of blocks */
  Extendedlab_M->Sizes.numBlockIO = (7);/* Number of block outputs */
  Extendedlab_M->Sizes.numBlockPrms = (68);/* Sum of parameter "widths" */
  return Extendedlab_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
