/*
 * SSnominalLab_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SSnominalLab".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Apr 12 10:19:45 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SSnominalLab.h"
#include "SSnominalLab_private.h"

/* Block parameters (default storage) */
P_SSnominalLab_T SSnominalLab_P = {
  /* Variable: robust
   * Referenced by:
   *   '<S2>/State feedback gain'
   *   '<S2>/ki'
   */
  {
    { 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, -24.635713612045045 },

    { 0.0, 0.0, 132.10946259615767 },

    { 0.0, 1.0, 0.0 },
    -20.0,
    27.28752707683682,

    { { -20.0, 27.28752707683682 }, { -20.0, -27.28752707683682 }, { -20.0, 0.0
      } },

    { -20.0, -20.0, -20.0 },

    { { -40.0, 27.28752707683682 }, { -40.0, -27.28752707683682 }, { -40.0, 0.0
      } },

    { { -40.0, 27.28752707683682 }, { -40.0, -27.28752707683682 }, { -60.0, 0.0
      } },

    { 173.28193022297361, 14.71968090517125, 0.26768927594580449 },
    173.28193022297361,

    { 14.71968090517125, 0.26768927594580449 },

    { 60.555843940225635, 9.0833765910338453, 0.26768927594580577 },
    60.555843940225635,

    { 9.0833765910338453, 0.26768927594580577 },

    { 709.89892408731635, 41.969810678273319, 0.7218581054975024 },
    709.89892408731635,

    { 41.969810678273319, 0.7218581054975024 },

    { 1064.8483861309771, 54.080979466318773, 0.87324771534806955 },
    1064.8483861309771,

    { 54.080979466318773, 0.87324771534806955 }
  },

  /* Variable: sens
   * Referenced by: '<Root>/pulse2deg'
   */
  {
    {
      0.5
    },

    {
      4096.0,
      0.087890625,
      0.0015339807878856412,
      11.377777777777778,
      651.89864690440334,
      0.001,
      0.087890625
    },

    {
      {
        10000.0,
        5.0,
        345.0,
        6.0213859193804371
      },
      0.014492753623188406,
      0.83037361613162786,
      69.0,
      1.2042771838760873
    }
  },

  /* Variable: deg2rad
   * Referenced by:
   *   '<S2>/deg2rad'
   *   '<S2>/deg2rad2'
   */
  0.017453292519943295,

  /* Variable: degs2rpm
   * Referenced by: '<S1>/degs2rpm'
   */
  0.16666666666666666,

  /* Variable: rpm2rads
   * Referenced by: '<S2>/rpm2rads'
   */
  0.10471975511965977,

  /* Mask Parameter: AnalogOutput_FinalValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_InitialValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: EncoderInput_InputFilter
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogInput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Input'
   */
  10.0,

  /* Mask Parameter: EncoderInput_MaxMissedTicks
   * Referenced by: '<Root>/Encoder Input'
   */
  10.0,

  /* Mask Parameter: AnalogOutput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Output'
   */
  10.0,

  /* Mask Parameter: AnalogInput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Input'
   */
  0.0,

  /* Mask Parameter: EncoderInput_YieldWhenWaiting
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: AnalogInput_Channels
   * Referenced by: '<Root>/Analog Input'
   */
  { 0, 1 },

  /* Mask Parameter: EncoderInput_Channels
   * Referenced by: '<Root>/Encoder Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_Channels
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_RangeMode
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_RangeMode
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_VoltRange
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_VoltRange
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Expression: 0
   * Referenced by: '<Root>/Ref'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Ref'
   */
  0.0,

  /* Expression: 120
   * Referenced by: '<Root>/Ref'
   */
  120.0,

  /* Expression: nominal.N_u
   * Referenced by: '<S2>/Input feedforward gain'
   */
  0.0,

  /* Expression: nominal.N_x
   * Referenced by: '<S2>/State feedforward gain'
   */
  { 1.0, -0.0 },

  /* Computed Parameter: Highpassfilter_A
   * Referenced by: '<S1>/High-pass filter'
   */
  { -444.2882938158366, -98696.044010893587 },

  /* Computed Parameter: Highpassfilter_C
   * Referenced by: '<S1>/High-pass filter'
   */
  { 98696.044010893587, 0.0 },

  /* Expression: 0
   * Referenced by: '<S2>/Integrator'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<S2>/Saturation'
   */
  10.0,

  /* Expression: -10
   * Referenced by: '<S2>/Saturation'
   */
  -10.0,

  /* Computed Parameter: integral_CurrentSetting
   * Referenced by: '<S2>/integral'
   */
  1U
};
