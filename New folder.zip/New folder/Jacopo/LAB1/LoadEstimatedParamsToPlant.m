mech.Jeq = est_par.J_eq;
mech.Beq = est_par.B_eq;
mld.tausf = est_par.tau_sf;