/*
 * ErrorSpaceLab_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ErrorSpaceLab".
 *
 * Model version              : 1.10
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Apr 12 11:24:09 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ErrorSpaceLab.h"
#include "ErrorSpaceLab_private.h"

/* Block parameters (default storage) */
P_ErrorSpaceLab_T ErrorSpaceLab_P = {
  /* Variable: es
   * Referenced by:
   *   '<S2>/Input feed-forward gain'
   *   '<S2>/Transfer Fcn'
   */
  {
    {
      41.887902047863911,

      { 363.43346463047897, -51048.861613839676, 335514.46966512373 },

      { 52.529225506292633, 0.87534759858930544 }
    },

    {
      25.132741228718345,

      { 1555.8034146671546, 2569.2486855722718, 335514.46967632114 },

      { 61.029352795040758, 0.87534759862553324 }
    },

    {
      12.566370614359172,

      { 2058.8344873076135, 30915.07896256564, 335514.46967972448 },

      { 64.615343993177817, 0.87534759862129652 }
    },

    {
      6.2831853071795862,

      { 2184.5922557142117, 38532.421254962763, 335514.46973789152 },

      { 65.511841798104143, 0.87534759866779666 }
    }
  },

  /* Variable: sens
   * Referenced by: '<Root>/pulse2deg1'
   */
  {
    {
      0.5
    },

    {
      4096.0,
      0.087890625,
      0.0015339807878856412,
      11.377777777777778,
      651.89864690440334,
      0.001,
      0.087890625
    },

    {
      {
        10000.0,
        5.0,
        345.0,
        6.0213859193804371
      },
      0.014492753623188406,
      0.83037361613162786,
      69.0,
      1.2042771838760873
    }
  },

  /* Variable: daq
   * Referenced by: '<S2>/Saturation'
   */
  {
    {
      16.0,
      10.0,
      0.00030518043793392844,
      0.001,
      10.0,
      -10.0
    },

    {
      16.0,
      10.0,
      0.00030518043793392844,
      0.001,
      10.0,
      -10.0
    }
  },

  /* Variable: deg2rad
   * Referenced by:
   *   '<S2>/deg2rad'
   *   '<S2>/deg2rad1'
   */
  0.017453292519943295,

  /* Variable: degs2rpm
   * Referenced by: '<S1>/Gain1'
   */
  0.16666666666666666,

  /* Variable: rpm2rads
   * Referenced by: '<S2>/rpm2rads'
   */
  0.10471975511965977,

  /* Mask Parameter: AnalogOutput_FinalValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_InitialValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: EncoderInput_InputFilter
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: EncoderInput_MaxMissedTicks
   * Referenced by: '<Root>/Encoder Input'
   */
  10.0,

  /* Mask Parameter: AnalogInput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Input'
   */
  10.0,

  /* Mask Parameter: AnalogOutput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Output'
   */
  10.0,

  /* Mask Parameter: EncoderInput_YieldWhenWaiting
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogInput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Input'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: EncoderInput_Channels
   * Referenced by: '<Root>/Encoder Input'
   */
  0,

  /* Mask Parameter: AnalogInput_Channels
   * Referenced by: '<Root>/Analog Input'
   */
  { 0, 1 },

  /* Mask Parameter: AnalogOutput_Channels
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_RangeMode
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_RangeMode
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_VoltRange
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_VoltRange
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Expression: 1
   * Referenced by: '<Root>/Sine Wave Generator1'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Sine Wave Generator1'
   */
  0.0,

  /* Expression: 2*pi/0.1
   * Referenced by: '<Root>/Sine Wave Generator1'
   */
  62.831853071795862,

  /* Expression: 0
   * Referenced by: '<Root>/Sine Wave Generator1'
   */
  0.0,

  /* Expression: [1 0 es.controller3.w0^2 0]
   * Referenced by: '<S2>/Transfer Fcn'
   */
  { 1.0, 0.0, 157.91367041742973, 0.0 },

  /* Computed Parameter: TransferFcn_A
   * Referenced by: '<S1>/Transfer Fcn'
   */
  { -444.2882938158366, -98696.044010893587 },

  /* Computed Parameter: TransferFcn_C
   * Referenced by: '<S1>/Transfer Fcn'
   */
  { 98696.044010893587, 0.0 },

  /* Expression: 0
   * Referenced by: '<Root>/Unit Step Generator1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Unit Step Generator1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Unit Step Generator1'
   */
  1.0,

  /* Expression: 40
   * Referenced by: '<Root>/Amplitude1'
   */
  40.0,

  /* Computed Parameter: ManualSwitch_CurrentSetting
   * Referenced by: '<Root>/Manual Switch'
   */
  1U
};
