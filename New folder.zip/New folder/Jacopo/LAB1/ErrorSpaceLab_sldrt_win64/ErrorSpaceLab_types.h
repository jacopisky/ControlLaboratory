/*
 * ErrorSpaceLab_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "ErrorSpaceLab".
 *
 * Model version              : 1.10
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon Apr 12 11:24:09 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ErrorSpaceLab_types_h_
#define RTW_HEADER_ErrorSpaceLab_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_struct_F3FGa1JndAOGVTLrjvwoWF_
#define DEFINED_TYPEDEF_FOR_struct_F3FGa1JndAOGVTLrjvwoWF_

typedef struct {
  real_T A[4];
  real_T B[2];
  real_T C[2];
  real_T D;
} struct_F3FGa1JndAOGVTLrjvwoWF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_GGRr1WqzQGoYdDwftEOdnF_
#define DEFINED_TYPEDEF_FOR_struct_GGRr1WqzQGoYdDwftEOdnF_

typedef struct {
  real_T Nx[2];
  real_T Nu;
  real_T K[2];
} struct_GGRr1WqzQGoYdDwftEOdnF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_Wxd4xdyIPd3zUL4qERXCoG_
#define DEFINED_TYPEDEF_FOR_struct_Wxd4xdyIPd3zUL4qERXCoG_

typedef struct {
  real_T wc;
  real_T delta;
} struct_Wxd4xdyIPd3zUL4qERXCoG;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_pOcUYTyZj44MajuAWHVJJB_
#define DEFINED_TYPEDEF_FOR_struct_pOcUYTyZj44MajuAWHVJJB_

typedef struct {
  struct_F3FGa1JndAOGVTLrjvwoWF plant;
  struct_GGRr1WqzQGoYdDwftEOdnF controller;
  struct_Wxd4xdyIPd3zUL4qERXCoG obs;
} struct_pOcUYTyZj44MajuAWHVJJB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_uZYCQFGYGtzB0S09zKTj5G_
#define DEFINED_TYPEDEF_FOR_struct_uZYCQFGYGtzB0S09zKTj5G_

typedef struct {
  real_T w0;
  real_T Kz[3];
  real_T Kpsi[2];
} struct_uZYCQFGYGtzB0S09zKTj5G;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_k43upDn37RadeiQTNBLSCE_
#define DEFINED_TYPEDEF_FOR_struct_k43upDn37RadeiQTNBLSCE_

typedef struct {
  struct_uZYCQFGYGtzB0S09zKTj5G controller1;
  struct_uZYCQFGYGtzB0S09zKTj5G controller2;
  struct_uZYCQFGYGtzB0S09zKTj5G controller3;
  struct_uZYCQFGYGtzB0S09zKTj5G controller4;
} struct_k43upDn37RadeiQTNBLSCE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_31AsIlQ7FTVxCnO4QlDNVE_
#define DEFINED_TYPEDEF_FOR_struct_31AsIlQ7FTVxCnO4QlDNVE_

typedef struct {
  real_T bits;
  real_T fs;
  real_T q;
  real_T T_s;
  real_T vdd;
  real_T vss;
} struct_31AsIlQ7FTVxCnO4QlDNVE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_xOUEnAVs9BF5Cm3MRDTnjB_
#define DEFINED_TYPEDEF_FOR_struct_xOUEnAVs9BF5Cm3MRDTnjB_

typedef struct {
  struct_31AsIlQ7FTVxCnO4QlDNVE dac;
  struct_31AsIlQ7FTVxCnO4QlDNVE adc;
} struct_xOUEnAVs9BF5Cm3MRDTnjB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_
#define DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_

typedef struct {
  real_T Rs;
} struct_vHPMdAr9HfDgWNbG6U3SfC;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_
#define DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_

typedef struct {
  real_T ppr;
  real_T pulse2deg;
  real_T pulse2rad;
  real_T deg2pulse;
  real_T rad2pulse;
  real_T T_s;
  real_T q;
} struct_L7PNJsBgXqfoUC1iyFkLDE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_
#define DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_

typedef struct {
  real_T R;
  real_T V;
  real_T th_deg;
  real_T th;
} struct_DqRrFctOcoTwJhkxMXTGZG;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_
#define DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_

typedef struct {
  struct_DqRrFctOcoTwJhkxMXTGZG range;
  real_T deg2V;
  real_T rad2V;
  real_T V2deg;
  real_T V2rad;
} struct_t4jfYKvXkqvqbOrnXV9flF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_coKXDsi5RvH3V98DgL1TfD_
#define DEFINED_TYPEDEF_FOR_struct_coKXDsi5RvH3V98DgL1TfD_

typedef struct {
  struct_vHPMdAr9HfDgWNbG6U3SfC curr;
  struct_L7PNJsBgXqfoUC1iyFkLDE enc;
  struct_t4jfYKvXkqvqbOrnXV9flF pot1;
} struct_coKXDsi5RvH3V98DgL1TfD;

#endif

/* Parameters (default storage) */
typedef struct P_ErrorSpaceLab_T_ P_ErrorSpaceLab_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_ErrorSpaceLab_T RT_MODEL_ErrorSpaceLab_T;

#endif                                 /* RTW_HEADER_ErrorSpaceLab_types_h_ */
