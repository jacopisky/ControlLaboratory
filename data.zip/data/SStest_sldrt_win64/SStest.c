/*
 * SStest.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SStest".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon May 10 12:38:22 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SStest.h"
#include "SStest_private.h"
#include "SStest_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6221", 4294967295U, 5, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_SStest_T SStest_B;

/* Continuous states */
X_SStest_T SStest_X;

/* Block states (default storage) */
DW_SStest_T SStest_DW;

/* Real-time model */
static RT_MODEL_SStest_T SStest_M_;
RT_MODEL_SStest_T *const SStest_M = &SStest_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 5;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  SStest_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  SStest_output();
  SStest_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  SStest_output();
  SStest_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void SStest_output(void)
{
  /* local block i/o variables */
  real_T rtb_AnalogInput[2];
  real_T rtb_Sum;
  real_T rtb_deg2rad;
  real_T tmp;
  if (rtmIsMajorTimeStep(SStest_M)) {
    /* set solver stop time */
    if (!(SStest_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&SStest_M->solverInfo,
                            ((SStest_M->Timing.clockTickH0 + 1) *
        SStest_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&SStest_M->solverInfo, ((SStest_M->Timing.clockTick0
        + 1) * SStest_M->Timing.stepSize0 + SStest_M->Timing.clockTickH0 *
        SStest_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(SStest_M)) {
    SStest_M->Timing.t[0] = rtsiGetT(&SStest_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(SStest_DW.Average_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(SStest_DW.StatespaceController_SubsysRanBC);

  /* Step: '<Root>/Step' incorporates:
   *  Step: '<Root>/Step1'
   */
  tmp = SStest_M->Timing.t[0];
  if (tmp < SStest_P.Step_Time) {
    /* Step: '<Root>/Step' */
    SStest_B.Step = SStest_P.Step_Y0;
  } else {
    /* Step: '<Root>/Step' */
    SStest_B.Step = SStest_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */
  if (rtmIsMajorTimeStep(SStest_M)) {
    /* S-Function (sldrtei): '<Root>/Encoder Input' */
    /* S-Function Block: <Root>/Encoder Input */
    {
      ENCODERINPARM parm;
      parm.quad = (QUADMODE) 2;
      parm.index = (INDEXPULSE) 0;
      parm.infilter = SStest_P.EncoderInput_InputFilter;
      RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1, &SStest_P.EncoderInput_Channels,
                     &rtb_Sum, &parm);
    }

    /* S-Function (sldrtai): '<Root>/Analog Input' */
    /* S-Function Block: <Root>/Analog Input */
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SStest_P.AnalogInput_RangeMode;
      parm.rangeidx = SStest_P.AnalogInput_VoltRange;
      RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2, SStest_P.AnalogInput_Channels,
                     &rtb_AnalogInput[0], &parm);
    }

    /* Gain: '<Root>/Gain' */
    SStest_B.Gain = SStest_P.sens.enc.pulse2deg * rtb_Sum;

    /* Sum: '<S1>/Sum' */
    rtb_Sum = rtb_AnalogInput[0] - rtb_AnalogInput[1];

    /* Gain: '<S1>/Gain' */
    SStest_B.Gain_l = SStest_P.sens.pot2.V2deg * rtb_Sum;
  }

  /* Clock: '<S4>/Clock' */
  rtb_deg2rad = SStest_M->Timing.t[0];

  /* Outputs for Enabled SubSystem: '<S4>/Average' incorporates:
   *  EnablePort: '<S5>/Enable'
   */
  if (rtmIsMajorTimeStep(SStest_M)) {
    /* Logic: '<S6>/AND' incorporates:
     *  Constant: '<S6>/Lower Limit'
     *  Constant: '<S6>/Upper Limit'
     *  RelationalOperator: '<S6>/Lower Test'
     *  RelationalOperator: '<S6>/Upper Test'
     */
    SStest_DW.Average_MODE = ((SStest_P.IntervalTest_lowlimit <= rtb_deg2rad) &&
      (rtb_deg2rad <= SStest_P.IntervalTest_uplimit));
  }

  if (SStest_DW.Average_MODE) {
    if (rtmIsMajorTimeStep(SStest_M)) {
      /* DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
      SStest_B.DiscreteTimeIntegrator = SStest_DW.DiscreteTimeIntegrator_DSTATE;
    }

    if (rtmIsMajorTimeStep(SStest_M)) {
      srUpdateBC(SStest_DW.Average_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S4>/Average' */

  /* Step: '<Root>/Step1' */
  if (tmp < SStest_P.Step1_Time) {
    /* Step: '<Root>/Step1' */
    SStest_B.Step1 = SStest_P.Step1_Y0;
  } else {
    /* Step: '<Root>/Step1' */
    SStest_B.Step1 = SStest_P.Step1_YFinal;
  }

  if (rtmIsMajorTimeStep(SStest_M)) {
    /* Sum: '<S1>/Sum1' */
    SStest_B.Sum1 = SStest_B.Gain_l - SStest_B.DiscreteTimeIntegrator;

    /* SignalConversion generated from: '<S3>/Enable' */
    SStest_B.HiddenBuf_InsertedFor_StatespaceController_at_inport_6 =
      SStest_B.Step1;

    /* Outputs for Enabled SubSystem: '<Root>/State-space Controller' incorporates:
     *  EnablePort: '<S3>/Enable'
     */
    if (rtmIsMajorTimeStep(SStest_M)) {
      SStest_DW.StatespaceController_MODE =
        (SStest_B.HiddenBuf_InsertedFor_StatespaceController_at_inport_6 > 0.0);
    }

    /* End of Outputs for SubSystem: '<Root>/State-space Controller' */
  }

  /* Outputs for Enabled SubSystem: '<Root>/State-space Controller' incorporates:
   *  EnablePort: '<S3>/Enable'
   */
  if (SStest_DW.StatespaceController_MODE) {
    /* Gain: '<S3>/deg2rad' */
    rtb_deg2rad = SStest_P.deg2rad * SStest_B.Step;
    if (rtmIsMajorTimeStep(SStest_M)) {
      /* Gain: '<S3>/deg2rad1' */
      SStest_B.deg2rad1 = SStest_P.deg2rad * SStest_B.Gain;

      /* Gain: '<S3>/deg2rad2' */
      SStest_B.deg2rad2 = SStest_P.deg2rad * SStest_B.Sum1;
    }

    /* Integrator: '<S3>/Integrator' */
    SStest_B.Integrator = SStest_X.Integrator_CSTATE;

    /* Switch: '<S3>/Switch' incorporates:
     *  Constant: '<Root>/Constant'
     *  Constant: '<S3>/Constant'
     */
    if (SStest_P.Constant_Value_k > SStest_P.Switch_Threshold) {
      tmp = SStest_B.Integrator;
    } else {
      tmp = SStest_P.Constant_Value;
    }

    /* End of Switch: '<S3>/Switch' */

    /* Sum: '<S3>/Sum1' incorporates:
     *  Gain: '<S2>/Gain'
     *  Gain: '<S2>/Gain1'
     *  Gain: '<S3>/Input feedforward gain'
     *  Gain: '<S3>/State feedback gain'
     *  Gain: '<S3>/State feedforward gain'
     *  Gain: '<S3>/deg2rad3'
     *  Gain: '<S3>/deg2rad4'
     *  Sum: '<S3>/Sum'
     *  TransferFcn: '<S2>/Real derivator'
     *  TransferFcn: '<S2>/Real derivator1'
     */
    SStest_B.Sum1_i = ((((SStest_P.nominal.N_x[2] * rtb_deg2rad -
                          (SStest_P.Realderivator_C[0] *
      SStest_X.Realderivator_CSTATE[0] + SStest_P.Realderivator_C[1] *
      SStest_X.Realderivator_CSTATE[1]) * SStest_P.degs2rpm * SStest_P.rpm2rads)
                         * SStest_P.Statefeedbackgain_Gain[2] +
                         ((SStest_P.nominal.N_x[0] * rtb_deg2rad -
      SStest_B.deg2rad1) * SStest_P.Statefeedbackgain_Gain[0] +
                          (SStest_P.nominal.N_x[1] * rtb_deg2rad -
      SStest_B.deg2rad2) * SStest_P.Statefeedbackgain_Gain[1])) +
                        (SStest_P.nominal.N_x[3] * rtb_deg2rad -
                         (SStest_P.Realderivator1_C[0] *
                          SStest_X.Realderivator1_CSTATE[0] +
                          SStest_P.Realderivator1_C[1] *
                          SStest_X.Realderivator1_CSTATE[1]) * SStest_P.degs2rpm
                         * SStest_P.deg2rad) * SStest_P.Statefeedbackgain_Gain[3])
                       + SStest_P.nominal.N_u * rtb_deg2rad) + tmp;
    if (rtmIsMajorTimeStep(SStest_M)) {
    }

    /* Gain: '<S3>/Ki' incorporates:
     *  Sum: '<S3>/Sum2'
     */
    SStest_B.Ki = (rtb_deg2rad - SStest_B.deg2rad1) * SStest_P.Ki_Gain;

    /* Saturate: '<S3>/Saturation' */
    if (SStest_B.Sum1_i > SStest_P.Saturation_UpperSat) {
      /* Saturate: '<S3>/Saturation' */
      SStest_B.Saturation = SStest_P.Saturation_UpperSat;
    } else if (SStest_B.Sum1_i < SStest_P.Saturation_LowerSat) {
      /* Saturate: '<S3>/Saturation' */
      SStest_B.Saturation = SStest_P.Saturation_LowerSat;
    } else {
      /* Saturate: '<S3>/Saturation' */
      SStest_B.Saturation = SStest_B.Sum1_i;
    }

    /* End of Saturate: '<S3>/Saturation' */
    if (rtmIsMajorTimeStep(SStest_M)) {
      srUpdateBC(SStest_DW.StatespaceController_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<Root>/State-space Controller' */
  if (rtmIsMajorTimeStep(SStest_M)) {
    /* S-Function (sldrtao): '<Root>/Analog Output' */
    /* S-Function Block: <Root>/Analog Output */
    {
      {
        ANALOGIOPARM parm;
        parm.mode = (RANGEMODE) SStest_P.AnalogOutput_RangeMode;
        parm.rangeidx = SStest_P.AnalogOutput_VoltRange;
        RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                       &SStest_P.AnalogOutput_Channels, ((real_T*)
          (&SStest_B.Saturation)), &parm);
      }
    }
  }
}

/* Model update function */
void SStest_update(void)
{
  /* Update for Enabled SubSystem: '<S4>/Average' incorporates:
   *  EnablePort: '<S5>/Enable'
   */
  if (SStest_DW.Average_MODE && rtmIsMajorTimeStep(SStest_M)) {
    /* Update for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
    SStest_DW.DiscreteTimeIntegrator_DSTATE +=
      SStest_P.DiscreteTimeIntegrator_gainval * SStest_B.Gain_l;
  }

  /* End of Update for SubSystem: '<S4>/Average' */
  if (rtmIsMajorTimeStep(SStest_M)) {
    rt_ertODEUpdateContinuousStates(&SStest_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++SStest_M->Timing.clockTick0)) {
    ++SStest_M->Timing.clockTickH0;
  }

  SStest_M->Timing.t[0] = rtsiGetSolverStopTime(&SStest_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++SStest_M->Timing.clockTick1)) {
      ++SStest_M->Timing.clockTickH1;
    }

    SStest_M->Timing.t[1] = SStest_M->Timing.clockTick1 *
      SStest_M->Timing.stepSize1 + SStest_M->Timing.clockTickH1 *
      SStest_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void SStest_derivatives(void)
{
  XDot_SStest_T *_rtXdot;
  _rtXdot = ((XDot_SStest_T *) SStest_M->derivs);

  /* Derivatives for TransferFcn: '<S2>/Real derivator' */
  _rtXdot->Realderivator_CSTATE[0] = 0.0;
  _rtXdot->Realderivator_CSTATE[0] += SStest_P.Realderivator_A[0] *
    SStest_X.Realderivator_CSTATE[0];
  _rtXdot->Realderivator_CSTATE[1] = 0.0;
  _rtXdot->Realderivator_CSTATE[0] += SStest_P.Realderivator_A[1] *
    SStest_X.Realderivator_CSTATE[1];
  _rtXdot->Realderivator_CSTATE[1] += SStest_X.Realderivator_CSTATE[0];
  _rtXdot->Realderivator_CSTATE[0] += SStest_B.Gain;

  /* Derivatives for TransferFcn: '<S2>/Real derivator1' */
  _rtXdot->Realderivator1_CSTATE[0] = 0.0;
  _rtXdot->Realderivator1_CSTATE[0] += SStest_P.Realderivator1_A[0] *
    SStest_X.Realderivator1_CSTATE[0];
  _rtXdot->Realderivator1_CSTATE[1] = 0.0;
  _rtXdot->Realderivator1_CSTATE[0] += SStest_P.Realderivator1_A[1] *
    SStest_X.Realderivator1_CSTATE[1];
  _rtXdot->Realderivator1_CSTATE[1] += SStest_X.Realderivator1_CSTATE[0];
  _rtXdot->Realderivator1_CSTATE[0] += SStest_B.Sum1;

  /* Derivatives for Enabled SubSystem: '<Root>/State-space Controller' */
  if (SStest_DW.StatespaceController_MODE) {
    /* Derivatives for Integrator: '<S3>/Integrator' */
    _rtXdot->Integrator_CSTATE = SStest_B.Ki;
  } else {
    ((XDot_SStest_T *) SStest_M->derivs)->Integrator_CSTATE = 0.0;
  }

  /* End of Derivatives for SubSystem: '<Root>/State-space Controller' */
}

/* Model initialize function */
void SStest_initialize(void)
{
  /* Start for Enabled SubSystem: '<S4>/Average' */
  SStest_DW.Average_MODE = false;

  /* End of Start for SubSystem: '<S4>/Average' */

  /* Start for Enabled SubSystem: '<Root>/State-space Controller' */
  SStest_DW.StatespaceController_MODE = false;

  /* End of Start for SubSystem: '<Root>/State-space Controller' */

  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SStest_P.AnalogOutput_RangeMode;
      parm.rangeidx = SStest_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &SStest_P.AnalogOutput_Channels,
                     &SStest_P.AnalogOutput_InitialValue, &parm);
    }
  }

  /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter = SStest_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1, &SStest_P.EncoderInput_Channels,
                   NULL, &parm);
  }

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator' */
  SStest_X.Realderivator_CSTATE[0] = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator1' */
  SStest_X.Realderivator1_CSTATE[0] = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator' */
  SStest_X.Realderivator_CSTATE[1] = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator1' */
  SStest_X.Realderivator1_CSTATE[1] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<S4>/Average' */
  /* InitializeConditions for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
  SStest_DW.DiscreteTimeIntegrator_DSTATE = SStest_P.DiscreteTimeIntegrator_IC;

  /* SystemInitialize for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' incorporates:
   *  Outport: '<S5>/Output'
   */
  SStest_B.DiscreteTimeIntegrator = SStest_P.Output_Y0;

  /* End of SystemInitialize for SubSystem: '<S4>/Average' */

  /* SystemInitialize for Enabled SubSystem: '<Root>/State-space Controller' */
  /* InitializeConditions for Integrator: '<S3>/Integrator' */
  SStest_X.Integrator_CSTATE = SStest_P.Integrator_IC;

  /* SystemInitialize for Saturate: '<S3>/Saturation' incorporates:
   *  Outport: '<S3>/u[V]'
   */
  SStest_B.Saturation = SStest_P.uV_Y0;

  /* End of SystemInitialize for SubSystem: '<Root>/State-space Controller' */
}

/* Model terminate function */
void SStest_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) SStest_P.AnalogOutput_RangeMode;
      parm.rangeidx = SStest_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &SStest_P.AnalogOutput_Channels,
                     &SStest_P.AnalogOutput_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  SStest_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  SStest_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  SStest_initialize();
}

void MdlTerminate(void)
{
  SStest_terminate();
}

/* Registration function */
RT_MODEL_SStest_T *SStest(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  SStest_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)SStest_M, 0,
                sizeof(RT_MODEL_SStest_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&SStest_M->solverInfo, &SStest_M->Timing.simTimeStep);
    rtsiSetTPtr(&SStest_M->solverInfo, &rtmGetTPtr(SStest_M));
    rtsiSetStepSizePtr(&SStest_M->solverInfo, &SStest_M->Timing.stepSize0);
    rtsiSetdXPtr(&SStest_M->solverInfo, &SStest_M->derivs);
    rtsiSetContStatesPtr(&SStest_M->solverInfo, (real_T **)
                         &SStest_M->contStates);
    rtsiSetNumContStatesPtr(&SStest_M->solverInfo,
      &SStest_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&SStest_M->solverInfo,
      &SStest_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&SStest_M->solverInfo,
      &SStest_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&SStest_M->solverInfo,
      &SStest_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&SStest_M->solverInfo, (&rtmGetErrorStatus(SStest_M)));
    rtsiSetRTModelPtr(&SStest_M->solverInfo, SStest_M);
  }

  rtsiSetSimTimeStep(&SStest_M->solverInfo, MAJOR_TIME_STEP);
  SStest_M->intgData.y = SStest_M->odeY;
  SStest_M->intgData.f[0] = SStest_M->odeF[0];
  SStest_M->intgData.f[1] = SStest_M->odeF[1];
  SStest_M->intgData.f[2] = SStest_M->odeF[2];
  SStest_M->contStates = ((real_T *) &SStest_X);
  rtsiSetSolverData(&SStest_M->solverInfo, (void *)&SStest_M->intgData);
  rtsiSetSolverName(&SStest_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = SStest_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    SStest_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    SStest_M->Timing.sampleTimes = (&SStest_M->Timing.sampleTimesArray[0]);
    SStest_M->Timing.offsetTimes = (&SStest_M->Timing.offsetTimesArray[0]);

    /* task periods */
    SStest_M->Timing.sampleTimes[0] = (0.0);
    SStest_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    SStest_M->Timing.offsetTimes[0] = (0.0);
    SStest_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(SStest_M, &SStest_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = SStest_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    SStest_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(SStest_M, 4.0);
  SStest_M->Timing.stepSize0 = 0.001;
  SStest_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  SStest_M->Sizes.checksums[0] = (842147305U);
  SStest_M->Sizes.checksums[1] = (2230774317U);
  SStest_M->Sizes.checksums[2] = (4020828078U);
  SStest_M->Sizes.checksums[3] = (218225948U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[3];
    SStest_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = (sysRanDType *)&SStest_DW.Average_SubsysRanBC;
    systemRan[2] = (sysRanDType *)&SStest_DW.StatespaceController_SubsysRanBC;
    rteiSetModelMappingInfoPtr(SStest_M->extModeInfo,
      &SStest_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(SStest_M->extModeInfo, SStest_M->Sizes.checksums);
    rteiSetTPtr(SStest_M->extModeInfo, rtmGetTPtr(SStest_M));
  }

  SStest_M->solverInfoPtr = (&SStest_M->solverInfo);
  SStest_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&SStest_M->solverInfo, 0.001);
  rtsiSetSolverMode(&SStest_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  SStest_M->blockIO = ((void *) &SStest_B);
  (void) memset(((void *) &SStest_B), 0,
                sizeof(B_SStest_T));

  /* parameters */
  SStest_M->defaultParam = ((real_T *)&SStest_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &SStest_X;
    SStest_M->contStates = (x);
    (void) memset((void *)&SStest_X, 0,
                  sizeof(X_SStest_T));
  }

  /* states (dwork) */
  SStest_M->dwork = ((void *) &SStest_DW);
  (void) memset((void *)&SStest_DW, 0,
                sizeof(DW_SStest_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    SStest_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 23;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  SStest_M->Sizes.numContStates = (5); /* Number of continuous states */
  SStest_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  SStest_M->Sizes.numY = (0);          /* Number of model outputs */
  SStest_M->Sizes.numU = (0);          /* Number of model inputs */
  SStest_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  SStest_M->Sizes.numSampTimes = (2);  /* Number of sample times */
  SStest_M->Sizes.numBlocks = (43);    /* Number of blocks */
  SStest_M->Sizes.numBlockIO = (14);   /* Number of block outputs */
  SStest_M->Sizes.numBlockPrms = (53); /* Sum of parameter "widths" */
  return SStest_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
