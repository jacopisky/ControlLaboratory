/*
 * SStest_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SStest".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon May 10 12:38:22 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SStest_types_h_
#define RTW_HEADER_SStest_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_
#define DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_

typedef struct {
  real_T Rs;
} struct_vHPMdAr9HfDgWNbG6U3SfC;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_
#define DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_

typedef struct {
  real_T ppr;
  real_T pulse2deg;
  real_T pulse2rad;
  real_T deg2pulse;
  real_T rad2pulse;
  real_T T_s;
  real_T q;
} struct_L7PNJsBgXqfoUC1iyFkLDE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_
#define DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_

typedef struct {
  real_T R;
  real_T V;
  real_T th_deg;
  real_T th;
} struct_DqRrFctOcoTwJhkxMXTGZG;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_
#define DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_

typedef struct {
  struct_DqRrFctOcoTwJhkxMXTGZG range;
  real_T deg2V;
  real_T rad2V;
  real_T V2deg;
  real_T V2rad;
} struct_t4jfYKvXkqvqbOrnXV9flF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_i7ZlkOl9k9qbhxQhPErSIE_
#define DEFINED_TYPEDEF_FOR_struct_i7ZlkOl9k9qbhxQhPErSIE_

typedef struct {
  real_T var;
} struct_i7ZlkOl9k9qbhxQhPErSIE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_nhbocl71hD6FRzHagkwJFB_
#define DEFINED_TYPEDEF_FOR_struct_nhbocl71hD6FRzHagkwJFB_

typedef struct {
  struct_DqRrFctOcoTwJhkxMXTGZG range;
  real_T deg2V;
  real_T rad2V;
  real_T V2deg;
  real_T V2rad;
  struct_i7ZlkOl9k9qbhxQhPErSIE noise;
} struct_nhbocl71hD6FRzHagkwJFB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_2UetnoeKRPLjw6pbKQs9iF_
#define DEFINED_TYPEDEF_FOR_struct_2UetnoeKRPLjw6pbKQs9iF_

typedef struct {
  struct_vHPMdAr9HfDgWNbG6U3SfC curr;
  struct_L7PNJsBgXqfoUC1iyFkLDE enc;
  struct_t4jfYKvXkqvqbOrnXV9flF pot1;
  struct_nhbocl71hD6FRzHagkwJFB pot2;
} struct_2UetnoeKRPLjw6pbKQs9iF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_SsqUAX3vmEAO9YAgi1rlE_
#define DEFINED_TYPEDEF_FOR_struct_SsqUAX3vmEAO9YAgi1rlE_

typedef struct {
  real_T wc;
  real_T d;
  real_T NUM[2];
  real_T DEN[3];
} struct_SsqUAX3vmEAO9YAgi1rlE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_1t6Y5bJyMySFpvhHMHxyoF_
#define DEFINED_TYPEDEF_FOR_struct_1t6Y5bJyMySFpvhHMHxyoF_

typedef struct {
  creal_T lambda1;
  creal_T lambda2;
  creal_T lambda3;
  creal_T lambda4;
  creal_T lambdas[4];
  real_T K[4];
  real_T X[5];
  real_T N_x[4];
  real_T N_u;
  real_T t[56299];
  real_T thh[56299];
  real_T Ref[56299];
} struct_1t6Y5bJyMySFpvhHMHxyoF;

#endif

/* Parameters (default storage) */
typedef struct P_SStest_T_ P_SStest_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_SStest_T RT_MODEL_SStest_T;

#endif                                 /* RTW_HEADER_SStest_types_h_ */
