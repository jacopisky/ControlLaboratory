/*
 * pidtest.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "pidtest".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon May 10 11:58:13 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pidtest.h"
#include "pidtest_private.h"
#include "pidtest_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6221", 4294967295U, 5, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_pidtest_T pidtest_B;

/* Continuous states */
X_pidtest_T pidtest_X;

/* Block states (default storage) */
DW_pidtest_T pidtest_DW;

/* Real-time model */
static RT_MODEL_pidtest_T pidtest_M_;
RT_MODEL_pidtest_T *const pidtest_M = &pidtest_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 6;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  pidtest_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  pidtest_output();
  pidtest_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  pidtest_output();
  pidtest_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void pidtest_output(void)
{
  /* local block i/o variables */
  real_T rtb_AnalogInput[2];
  real_T rtb_Sum_e;
  real_T rtb_Clock;
  real_T tmp;
  if (rtmIsMajorTimeStep(pidtest_M)) {
    /* set solver stop time */
    if (!(pidtest_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&pidtest_M->solverInfo,
                            ((pidtest_M->Timing.clockTickH0 + 1) *
        pidtest_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&pidtest_M->solverInfo,
                            ((pidtest_M->Timing.clockTick0 + 1) *
        pidtest_M->Timing.stepSize0 + pidtest_M->Timing.clockTickH0 *
        pidtest_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(pidtest_M)) {
    pidtest_M->Timing.t[0] = rtsiGetT(&pidtest_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(pidtest_DW.Average_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(pidtest_DW.Controller_SubsysRanBC);

  /* Step: '<Root>/Step' incorporates:
   *  Step: '<Root>/Step1'
   */
  tmp = pidtest_M->Timing.t[0];
  if (tmp < pidtest_P.Step_Time) {
    /* Step: '<Root>/Step' */
    pidtest_B.Step = pidtest_P.Step_Y0;
  } else {
    /* Step: '<Root>/Step' */
    pidtest_B.Step = pidtest_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */
  if (rtmIsMajorTimeStep(pidtest_M)) {
    /* S-Function (sldrtei): '<Root>/Encoder Input' */
    /* S-Function Block: <Root>/Encoder Input */
    {
      ENCODERINPARM parm;
      parm.quad = (QUADMODE) 2;
      parm.index = (INDEXPULSE) 0;
      parm.infilter = pidtest_P.EncoderInput_InputFilter;
      RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1,
                     &pidtest_P.EncoderInput_Channels, &rtb_Sum_e, &parm);
    }

    /* S-Function (sldrtai): '<Root>/Analog Input' */
    /* S-Function Block: <Root>/Analog Input */
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) pidtest_P.AnalogInput_RangeMode;
      parm.rangeidx = pidtest_P.AnalogInput_VoltRange;
      RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2, pidtest_P.AnalogInput_Channels,
                     &rtb_AnalogInput[0], &parm);
    }

    /* Gain: '<Root>/Gain' */
    pidtest_B.Gain = pidtest_P.sens.enc.pulse2deg * rtb_Sum_e;
  }

  /* Step: '<Root>/Step1' */
  if (tmp < pidtest_P.Step1_Time) {
    /* Step: '<Root>/Step1' */
    pidtest_B.Step1 = pidtest_P.Step1_Y0;
  } else {
    /* Step: '<Root>/Step1' */
    pidtest_B.Step1 = pidtest_P.Step1_YFinal;
  }

  if (rtmIsMajorTimeStep(pidtest_M)) {
    /* SignalConversion generated from: '<S2>/Enable' */
    pidtest_B.HiddenBuf_InsertedFor_Controller_at_inport_2 = pidtest_B.Step1;

    /* Outputs for Enabled SubSystem: '<Root>/Controller' incorporates:
     *  EnablePort: '<S2>/Enable'
     */
    if (rtmIsMajorTimeStep(pidtest_M)) {
      pidtest_DW.Controller_MODE =
        (pidtest_B.HiddenBuf_InsertedFor_Controller_at_inport_2 > 0.0);
    }

    /* End of Outputs for SubSystem: '<Root>/Controller' */
  }

  /* Outputs for Enabled SubSystem: '<Root>/Controller' incorporates:
   *  EnablePort: '<S2>/Enable'
   */
  if (pidtest_DW.Controller_MODE) {
    /* Gain: '<S2>/deg2rad' incorporates:
     *  Sum: '<Root>/Sum'
     */
    rtb_Clock = (pidtest_B.Step - pidtest_B.Gain) * pidtest_P.deg2rad;

    /* Gain: '<S2>/Kd' */
    pidtest_B.Kd = pidtest_P.Kd_Gain * rtb_Clock;

    /* Sum: '<S2>/Sum' incorporates:
     *  Gain: '<S2>/Kp'
     *  Integrator: '<S2>/Integrator'
     *  TransferFcn: '<S2>/Real derivator'
     */
    pidtest_B.Sum = ((pidtest_P.Realderivator_C *
                      pidtest_X.Realderivator_CSTATE_a +
                      pidtest_P.Realderivator_D * pidtest_B.Kd) +
                     pidtest_P.Kp_Gain * rtb_Clock) +
      pidtest_X.Integrator_CSTATE;
    if (rtmIsMajorTimeStep(pidtest_M)) {
    }

    /* Saturate: '<S2>/Saturation' */
    if (pidtest_B.Sum > pidtest_P.Saturation_UpperSat) {
      /* Saturate: '<S2>/Saturation' */
      pidtest_B.Saturation = pidtest_P.Saturation_UpperSat;
    } else if (pidtest_B.Sum < pidtest_P.Saturation_LowerSat) {
      /* Saturate: '<S2>/Saturation' */
      pidtest_B.Saturation = pidtest_P.Saturation_LowerSat;
    } else {
      /* Saturate: '<S2>/Saturation' */
      pidtest_B.Saturation = pidtest_B.Sum;
    }

    /* End of Saturate: '<S2>/Saturation' */

    /* Switch: '<S2>/Switch' incorporates:
     *  Constant: '<Root>/Constant'
     *  Constant: '<S2>/Constant'
     *  Sum: '<S2>/Sum1'
     */
    if (pidtest_P.Constant_Value_k > pidtest_P.Switch_Threshold) {
      tmp = pidtest_B.Sum - pidtest_B.Saturation;
    } else {
      tmp = pidtest_P.Constant_Value;
    }

    /* End of Switch: '<S2>/Switch' */

    /* Sum: '<S2>/Sum2' incorporates:
     *  Gain: '<S2>/Gain3'
     *  Gain: '<S2>/Ki'
     */
    pidtest_B.Sum2 = pidtest_P.Ki_Gain * rtb_Clock - pidtest_P.AW.Kw * tmp;
    if (rtmIsMajorTimeStep(pidtest_M)) {
      srUpdateBC(pidtest_DW.Controller_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<Root>/Controller' */
  if (rtmIsMajorTimeStep(pidtest_M)) {
    /* S-Function (sldrtao): '<Root>/Analog Output' */
    /* S-Function Block: <Root>/Analog Output */
    {
      {
        ANALOGIOPARM parm;
        parm.mode = (RANGEMODE) pidtest_P.AnalogOutput_RangeMode;
        parm.rangeidx = pidtest_P.AnalogOutput_VoltRange;
        RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                       &pidtest_P.AnalogOutput_Channels, ((real_T*)
          (&pidtest_B.Saturation)), &parm);
      }
    }
  }

  /* Clock: '<S4>/Clock' */
  rtb_Clock = pidtest_M->Timing.t[0];

  /* Outputs for Enabled SubSystem: '<S4>/Average' incorporates:
   *  EnablePort: '<S5>/Enable'
   */
  if (rtmIsMajorTimeStep(pidtest_M)) {
    /* Logic: '<S6>/AND' incorporates:
     *  Constant: '<S6>/Lower Limit'
     *  Constant: '<S6>/Upper Limit'
     *  RelationalOperator: '<S6>/Lower Test'
     *  RelationalOperator: '<S6>/Upper Test'
     */
    pidtest_DW.Average_MODE = ((pidtest_P.IntervalTest_lowlimit <= rtb_Clock) &&
      (rtb_Clock <= pidtest_P.IntervalTest_uplimit));
  }

  if (pidtest_DW.Average_MODE) {
    if (rtmIsMajorTimeStep(pidtest_M)) {
      /* DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
      pidtest_B.DiscreteTimeIntegrator =
        pidtest_DW.DiscreteTimeIntegrator_DSTATE;
    }

    if (rtmIsMajorTimeStep(pidtest_M)) {
      srUpdateBC(pidtest_DW.Average_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S4>/Average' */
  if (rtmIsMajorTimeStep(pidtest_M)) {
    /* Sum: '<S1>/Sum' */
    rtb_Sum_e = rtb_AnalogInput[0] - rtb_AnalogInput[1];

    /* Gain: '<S1>/Gain' */
    pidtest_B.Gain_l = pidtest_P.sens.pot2.V2deg * rtb_Sum_e;

    /* Sum: '<S1>/Sum1' */
    pidtest_B.Sum1 = pidtest_B.Gain_l - pidtest_B.DiscreteTimeIntegrator;
  }
}

/* Model update function */
void pidtest_update(void)
{
  /* Update for Enabled SubSystem: '<S4>/Average' incorporates:
   *  EnablePort: '<S5>/Enable'
   */
  if (pidtest_DW.Average_MODE && rtmIsMajorTimeStep(pidtest_M)) {
    /* Update for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
    pidtest_DW.DiscreteTimeIntegrator_DSTATE +=
      pidtest_P.DiscreteTimeIntegrator_gainval * pidtest_B.Gain_l;
  }

  /* End of Update for SubSystem: '<S4>/Average' */
  if (rtmIsMajorTimeStep(pidtest_M)) {
    rt_ertODEUpdateContinuousStates(&pidtest_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++pidtest_M->Timing.clockTick0)) {
    ++pidtest_M->Timing.clockTickH0;
  }

  pidtest_M->Timing.t[0] = rtsiGetSolverStopTime(&pidtest_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++pidtest_M->Timing.clockTick1)) {
      ++pidtest_M->Timing.clockTickH1;
    }

    pidtest_M->Timing.t[1] = pidtest_M->Timing.clockTick1 *
      pidtest_M->Timing.stepSize1 + pidtest_M->Timing.clockTickH1 *
      pidtest_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void pidtest_derivatives(void)
{
  XDot_pidtest_T *_rtXdot;
  _rtXdot = ((XDot_pidtest_T *) pidtest_M->derivs);

  /* Derivatives for Enabled SubSystem: '<Root>/Controller' */
  if (pidtest_DW.Controller_MODE) {
    /* Derivatives for TransferFcn: '<S2>/Real derivator' */
    _rtXdot->Realderivator_CSTATE_a = 0.0;
    _rtXdot->Realderivator_CSTATE_a += pidtest_P.Realderivator_A *
      pidtest_X.Realderivator_CSTATE_a;
    _rtXdot->Realderivator_CSTATE_a += pidtest_B.Kd;

    /* Derivatives for Integrator: '<S2>/Integrator' */
    _rtXdot->Integrator_CSTATE = pidtest_B.Sum2;
  } else {
    {
      real_T *dx;
      int_T i;
      dx = &(((XDot_pidtest_T *) pidtest_M->derivs)->Realderivator_CSTATE_a);
      for (i=0; i < 2; i++) {
        dx[i] = 0.0;
      }
    }
  }

  /* End of Derivatives for SubSystem: '<Root>/Controller' */

  /* Derivatives for TransferFcn: '<S3>/Real derivator' */
  _rtXdot->Realderivator_CSTATE[0] = 0.0;
  _rtXdot->Realderivator_CSTATE[0] += pidtest_P.Realderivator_A_c[0] *
    pidtest_X.Realderivator_CSTATE[0];
  _rtXdot->Realderivator_CSTATE[1] = 0.0;
  _rtXdot->Realderivator_CSTATE[0] += pidtest_P.Realderivator_A_c[1] *
    pidtest_X.Realderivator_CSTATE[1];
  _rtXdot->Realderivator_CSTATE[1] += pidtest_X.Realderivator_CSTATE[0];
  _rtXdot->Realderivator_CSTATE[0] += pidtest_B.Gain;

  /* Derivatives for TransferFcn: '<S3>/Real derivator1' */
  _rtXdot->Realderivator1_CSTATE[0] = 0.0;
  _rtXdot->Realderivator1_CSTATE[0] += pidtest_P.Realderivator1_A[0] *
    pidtest_X.Realderivator1_CSTATE[0];
  _rtXdot->Realderivator1_CSTATE[1] = 0.0;
  _rtXdot->Realderivator1_CSTATE[0] += pidtest_P.Realderivator1_A[1] *
    pidtest_X.Realderivator1_CSTATE[1];
  _rtXdot->Realderivator1_CSTATE[1] += pidtest_X.Realderivator1_CSTATE[0];
  _rtXdot->Realderivator1_CSTATE[0] += pidtest_B.Sum1;
}

/* Model initialize function */
void pidtest_initialize(void)
{
  /* Start for Enabled SubSystem: '<Root>/Controller' */
  pidtest_DW.Controller_MODE = false;

  /* End of Start for SubSystem: '<Root>/Controller' */

  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */

  /* no initial value should be set */

  /* Start for Enabled SubSystem: '<S4>/Average' */
  pidtest_DW.Average_MODE = false;

  /* End of Start for SubSystem: '<S4>/Average' */

  /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter = pidtest_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1, &pidtest_P.EncoderInput_Channels,
                   NULL, &parm);
  }

  /* InitializeConditions for TransferFcn: '<S3>/Real derivator' */
  pidtest_X.Realderivator_CSTATE[0] = 0.0;

  /* InitializeConditions for TransferFcn: '<S3>/Real derivator1' */
  pidtest_X.Realderivator1_CSTATE[0] = 0.0;

  /* InitializeConditions for TransferFcn: '<S3>/Real derivator' */
  pidtest_X.Realderivator_CSTATE[1] = 0.0;

  /* InitializeConditions for TransferFcn: '<S3>/Real derivator1' */
  pidtest_X.Realderivator1_CSTATE[1] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<Root>/Controller' */
  /* InitializeConditions for TransferFcn: '<S2>/Real derivator' */
  pidtest_X.Realderivator_CSTATE_a = 0.0;

  /* InitializeConditions for Integrator: '<S2>/Integrator' */
  pidtest_X.Integrator_CSTATE = pidtest_P.Integrator_IC;

  /* SystemInitialize for Saturate: '<S2>/Saturation' incorporates:
   *  Outport: '<S2>/Out [rad]'
   */
  pidtest_B.Saturation = pidtest_P.Outrad_Y0;

  /* End of SystemInitialize for SubSystem: '<Root>/Controller' */

  /* SystemInitialize for Enabled SubSystem: '<S4>/Average' */
  /* InitializeConditions for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
  pidtest_DW.DiscreteTimeIntegrator_DSTATE = pidtest_P.DiscreteTimeIntegrator_IC;

  /* SystemInitialize for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' incorporates:
   *  Outport: '<S5>/Output'
   */
  pidtest_B.DiscreteTimeIntegrator = pidtest_P.Output_Y0;

  /* End of SystemInitialize for SubSystem: '<S4>/Average' */
}

/* Model terminate function */
void pidtest_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */

  /* no final value should be set */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  pidtest_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  pidtest_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  pidtest_initialize();
}

void MdlTerminate(void)
{
  pidtest_terminate();
}

/* Registration function */
RT_MODEL_pidtest_T *pidtest(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  pidtest_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)pidtest_M, 0,
                sizeof(RT_MODEL_pidtest_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&pidtest_M->solverInfo, &pidtest_M->Timing.simTimeStep);
    rtsiSetTPtr(&pidtest_M->solverInfo, &rtmGetTPtr(pidtest_M));
    rtsiSetStepSizePtr(&pidtest_M->solverInfo, &pidtest_M->Timing.stepSize0);
    rtsiSetdXPtr(&pidtest_M->solverInfo, &pidtest_M->derivs);
    rtsiSetContStatesPtr(&pidtest_M->solverInfo, (real_T **)
                         &pidtest_M->contStates);
    rtsiSetNumContStatesPtr(&pidtest_M->solverInfo,
      &pidtest_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&pidtest_M->solverInfo,
      &pidtest_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&pidtest_M->solverInfo,
      &pidtest_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&pidtest_M->solverInfo,
      &pidtest_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&pidtest_M->solverInfo, (&rtmGetErrorStatus(pidtest_M)));
    rtsiSetRTModelPtr(&pidtest_M->solverInfo, pidtest_M);
  }

  rtsiSetSimTimeStep(&pidtest_M->solverInfo, MAJOR_TIME_STEP);
  pidtest_M->intgData.y = pidtest_M->odeY;
  pidtest_M->intgData.f[0] = pidtest_M->odeF[0];
  pidtest_M->intgData.f[1] = pidtest_M->odeF[1];
  pidtest_M->intgData.f[2] = pidtest_M->odeF[2];
  pidtest_M->contStates = ((real_T *) &pidtest_X);
  rtsiSetSolverData(&pidtest_M->solverInfo, (void *)&pidtest_M->intgData);
  rtsiSetSolverName(&pidtest_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = pidtest_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    pidtest_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    pidtest_M->Timing.sampleTimes = (&pidtest_M->Timing.sampleTimesArray[0]);
    pidtest_M->Timing.offsetTimes = (&pidtest_M->Timing.offsetTimesArray[0]);

    /* task periods */
    pidtest_M->Timing.sampleTimes[0] = (0.0);
    pidtest_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    pidtest_M->Timing.offsetTimes[0] = (0.0);
    pidtest_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(pidtest_M, &pidtest_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = pidtest_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    pidtest_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(pidtest_M, 4.0);
  pidtest_M->Timing.stepSize0 = 0.001;
  pidtest_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  pidtest_M->Sizes.checksums[0] = (15374114U);
  pidtest_M->Sizes.checksums[1] = (750962727U);
  pidtest_M->Sizes.checksums[2] = (1591759657U);
  pidtest_M->Sizes.checksums[3] = (1561508802U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[4];
    pidtest_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = (sysRanDType *)&pidtest_DW.Average_SubsysRanBC;
    systemRan[2] = (sysRanDType *)&pidtest_DW.Controller_SubsysRanBC;
    systemRan[3] = (sysRanDType *)&pidtest_DW.Controller_SubsysRanBC;
    rteiSetModelMappingInfoPtr(pidtest_M->extModeInfo,
      &pidtest_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(pidtest_M->extModeInfo, pidtest_M->Sizes.checksums);
    rteiSetTPtr(pidtest_M->extModeInfo, rtmGetTPtr(pidtest_M));
  }

  pidtest_M->solverInfoPtr = (&pidtest_M->solverInfo);
  pidtest_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&pidtest_M->solverInfo, 0.001);
  rtsiSetSolverMode(&pidtest_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  pidtest_M->blockIO = ((void *) &pidtest_B);
  (void) memset(((void *) &pidtest_B), 0,
                sizeof(B_pidtest_T));

  /* parameters */
  pidtest_M->defaultParam = ((real_T *)&pidtest_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &pidtest_X;
    pidtest_M->contStates = (x);
    (void) memset((void *)&pidtest_X, 0,
                  sizeof(X_pidtest_T));
  }

  /* states (dwork) */
  pidtest_M->dwork = ((void *) &pidtest_DW);
  (void) memset((void *)&pidtest_DW, 0,
                sizeof(DW_pidtest_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    pidtest_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 23;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  pidtest_M->Sizes.numContStates = (6);/* Number of continuous states */
  pidtest_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  pidtest_M->Sizes.numY = (0);         /* Number of model outputs */
  pidtest_M->Sizes.numU = (0);         /* Number of model inputs */
  pidtest_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  pidtest_M->Sizes.numSampTimes = (2); /* Number of sample times */
  pidtest_M->Sizes.numBlocks = (39);   /* Number of blocks */
  pidtest_M->Sizes.numBlockIO = (12);  /* Number of block outputs */
  pidtest_M->Sizes.numBlockPrms = (50);/* Sum of parameter "widths" */
  return pidtest_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
