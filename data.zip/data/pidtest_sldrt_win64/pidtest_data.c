/*
 * pidtest_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "pidtest".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon May 10 11:58:13 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pidtest.h"
#include "pidtest_private.h"

/* Block parameters (default storage) */
P_pidtest_T pidtest_P = {
  /* Variable: sens
   * Referenced by:
   *   '<Root>/Gain'
   *   '<S1>/Gain'
   */
  {
    {
      0.5
    },

    {
      4096.0,
      0.087890625,
      0.0015339807878856412,
      11.377777777777778,
      651.89864690440334,
      0.001,
      0.087890625
    },

    {
      {
        10000.0,
        5.0,
        345.0,
        6.0213859193804371
      },
      0.014492753623188406,
      0.83037361613162786,
      69.0,
      1.2042771838760873
    },

    {
      {
        10000.0,
        5.0,
        340.0,
        5.9341194567807207
      },
      0.014705882352941176,
      0.84258499283944588,
      68.0,
      1.1868238913561442,

      {
        3.5e-7
      }
    }
  },

  /* Variable: deg2rad
   * Referenced by: '<S2>/deg2rad'
   */
  0.017453292519943295,

  /* Variable: AW
   * Referenced by: '<S2>/Gain3'
   */
  {
    5.882352941176471
  },

  /* Mask Parameter: EncoderInput_InputFilter
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: EncoderInput_MaxMissedTicks
   * Referenced by: '<Root>/Encoder Input'
   */
  10.0,

  /* Mask Parameter: AnalogInput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Input'
   */
  10.0,

  /* Mask Parameter: AnalogOutput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Output'
   */
  10.0,

  /* Mask Parameter: EncoderInput_YieldWhenWaiting
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogInput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Input'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: IntervalTest_lowlimit
   * Referenced by: '<S6>/Lower Limit'
   */
  0.2,

  /* Mask Parameter: IntervalTest_uplimit
   * Referenced by: '<S6>/Upper Limit'
   */
  0.7,

  /* Mask Parameter: EncoderInput_Channels
   * Referenced by: '<Root>/Encoder Input'
   */
  0,

  /* Mask Parameter: AnalogInput_Channels
   * Referenced by: '<Root>/Analog Input'
   */
  { 2, 3 },

  /* Mask Parameter: AnalogOutput_Channels
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_RangeMode
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_RangeMode
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_VoltRange
   * Referenced by: '<Root>/Analog Input'
   */
  1,

  /* Mask Parameter: AnalogOutput_VoltRange
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Computed Parameter: Output_Y0
   * Referenced by: '<S5>/Output'
   */
  0.0,

  /* Computed Parameter: DiscreteTimeIntegrator_gainval
   * Referenced by: '<S5>/Discrete-Time Integrator'
   */
  0.0020000000000000005,

  /* Expression: 0
   * Referenced by: '<S5>/Discrete-Time Integrator'
   */
  0.0,

  /* Computed Parameter: Outrad_Y0
   * Referenced by: '<S2>/Out [rad]'
   */
  0.0,

  /* Expression: PID.kp
   * Referenced by: '<S2>/Kp'
   */
  10.646552922171512,

  /* Expression: PID.kd
   * Referenced by: '<S2>/Kd'
   */
  0.80070710899856079,

  /* Computed Parameter: Realderivator_A
   * Referenced by: '<S2>/Real derivator'
   */
  -98.626280262792534,

  /* Computed Parameter: Realderivator_C
   * Referenced by: '<S2>/Real derivator'
   */
  -9727.1431584749,

  /* Computed Parameter: Realderivator_D
   * Referenced by: '<S2>/Real derivator'
   */
  98.626280262792534,

  /* Expression: 0
   * Referenced by: '<S2>/Integrator'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Constant'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<S2>/Saturation'
   */
  10.0,

  /* Expression: -10
   * Referenced by: '<S2>/Saturation'
   */
  -10.0,

  /* Expression: 0
   * Referenced by: '<S2>/Switch'
   */
  0.0,

  /* Expression: PID.ki
   * Referenced by: '<S2>/Ki'
   */
  35.390309343688649,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 120
   * Referenced by: '<Root>/Step'
   */
  120.0,

  /* Expression: 1
   * Referenced by: '<Root>/Constant'
   */
  1.0,

  /* Expression: 0.7
   * Referenced by: '<Root>/Step1'
   */
  0.7,

  /* Expression: 0
   * Referenced by: '<Root>/Step1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Step1'
   */
  1.0,

  /* Computed Parameter: Realderivator_A_c
   * Referenced by: '<S3>/Real derivator'
   */
  { -444.2882938158366, -98696.044010893587 },

  /* Computed Parameter: Realderivator_C_b
   * Referenced by: '<S3>/Real derivator'
   */
  { 98696.044010893587, 0.0 },

  /* Computed Parameter: Realderivator1_A
   * Referenced by: '<S3>/Real derivator1'
   */
  { -444.2882938158366, -98696.044010893587 },

  /* Computed Parameter: Realderivator1_C
   * Referenced by: '<S3>/Real derivator1'
   */
  { 98696.044010893587, 0.0 }
};
