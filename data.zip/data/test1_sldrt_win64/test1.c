/*
 * test1.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "test1".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon May 10 10:43:19 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "test1.h"
#include "test1_private.h"
#include "test1_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6221", 4294967295U, 5, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_test1_T test1_B;

/* Continuous states */
X_test1_T test1_X;

/* Block states (default storage) */
DW_test1_T test1_DW;

/* Real-time model */
static RT_MODEL_test1_T test1_M_;
RT_MODEL_test1_T *const test1_M = &test1_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  test1_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  test1_output();
  test1_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  test1_output();
  test1_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void test1_output(void)
{
  /* local block i/o variables */
  real_T rtb_AnalogInput[2];
  real_T rtb_EncoderInput;
  real_T rtb_Clock;
  if (rtmIsMajorTimeStep(test1_M)) {
    /* set solver stop time */
    if (!(test1_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&test1_M->solverInfo, ((test1_M->Timing.clockTickH0
        + 1) * test1_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&test1_M->solverInfo, ((test1_M->Timing.clockTick0 +
        1) * test1_M->Timing.stepSize0 + test1_M->Timing.clockTickH0 *
        test1_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(test1_M)) {
    test1_M->Timing.t[0] = rtsiGetT(&test1_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(test1_DW.Average_SubsysRanBC);
  if (rtmIsMajorTimeStep(test1_M)) {
    /* S-Function (sldrtai): '<Root>/Analog Input' */
    /* S-Function Block: <Root>/Analog Input */
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) test1_P.AnalogInput_RangeMode;
      parm.rangeidx = test1_P.AnalogInput_VoltRange;
      RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2, test1_P.AnalogInput_Channels,
                     &rtb_AnalogInput[0], &parm);
    }

    /* S-Function (sldrtei): '<Root>/Encoder Input' */
    /* S-Function Block: <Root>/Encoder Input */
    {
      ENCODERINPARM parm;
      parm.quad = (QUADMODE) 2;
      parm.index = (INDEXPULSE) 0;
      parm.infilter = test1_P.EncoderInput_InputFilter;
      RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1, &test1_P.EncoderInput_Channels,
                     &rtb_EncoderInput, &parm);
    }

    /* Gain: '<S1>/Gain' incorporates:
     *  Sum: '<S1>/Sum'
     */
    test1_B.Gain = (rtb_AnalogInput[0] - rtb_AnalogInput[1]) *
      test1_P.sens.pot2.V2deg;
  }

  /* Clock: '<S3>/Clock' */
  rtb_Clock = test1_M->Timing.t[0];

  /* Outputs for Enabled SubSystem: '<S3>/Average' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  if (rtmIsMajorTimeStep(test1_M)) {
    /* Logic: '<S5>/AND' incorporates:
     *  Constant: '<S5>/Lower Limit'
     *  Constant: '<S5>/Upper Limit'
     *  RelationalOperator: '<S5>/Lower Test'
     *  RelationalOperator: '<S5>/Upper Test'
     */
    test1_DW.Average_MODE = ((test1_P.IntervalTest_lowlimit <= rtb_Clock) &&
      (rtb_Clock <= test1_P.IntervalTest_uplimit));
  }

  if (test1_DW.Average_MODE) {
    if (rtmIsMajorTimeStep(test1_M)) {
      /* DiscreteIntegrator: '<S4>/Discrete-Time Integrator' */
      test1_B.DiscreteTimeIntegrator = test1_DW.DiscreteTimeIntegrator_DSTATE;
    }

    if (rtmIsMajorTimeStep(test1_M)) {
      srUpdateBC(test1_DW.Average_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S3>/Average' */
  if (rtmIsMajorTimeStep(test1_M)) {
    /* Sum: '<S1>/Sum1' */
    test1_B.Sum1 = test1_B.Gain - test1_B.DiscreteTimeIntegrator;

    /* Gain: '<Root>/Gain' */
    test1_B.Gain_b = test1_P.sens.enc.pulse2deg * rtb_EncoderInput;

    /* S-Function (sldrtao): '<Root>/Analog Output' incorporates:
     *  Constant: '<Root>/Constant'
     */
    /* S-Function Block: <Root>/Analog Output */
    {
      {
        ANALOGIOPARM parm;
        parm.mode = (RANGEMODE) test1_P.AnalogOutput_RangeMode;
        parm.rangeidx = test1_P.AnalogOutput_VoltRange;
        RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                       &test1_P.AnalogOutput_Channels, ((real_T*)
          (&test1_P.Constant_Value)), &parm);
      }
    }
  }
}

/* Model update function */
void test1_update(void)
{
  /* Update for Enabled SubSystem: '<S3>/Average' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  if (test1_DW.Average_MODE && rtmIsMajorTimeStep(test1_M)) {
    /* Update for DiscreteIntegrator: '<S4>/Discrete-Time Integrator' */
    test1_DW.DiscreteTimeIntegrator_DSTATE +=
      test1_P.DiscreteTimeIntegrator_gainval * test1_B.Gain;
  }

  /* End of Update for SubSystem: '<S3>/Average' */
  if (rtmIsMajorTimeStep(test1_M)) {
    rt_ertODEUpdateContinuousStates(&test1_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++test1_M->Timing.clockTick0)) {
    ++test1_M->Timing.clockTickH0;
  }

  test1_M->Timing.t[0] = rtsiGetSolverStopTime(&test1_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++test1_M->Timing.clockTick1)) {
      ++test1_M->Timing.clockTickH1;
    }

    test1_M->Timing.t[1] = test1_M->Timing.clockTick1 *
      test1_M->Timing.stepSize1 + test1_M->Timing.clockTickH1 *
      test1_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void test1_derivatives(void)
{
  XDot_test1_T *_rtXdot;
  _rtXdot = ((XDot_test1_T *) test1_M->derivs);

  /* Derivatives for TransferFcn: '<S2>/Real derivator' */
  _rtXdot->Realderivator_CSTATE[0] = 0.0;
  _rtXdot->Realderivator_CSTATE[0] += test1_P.Realderivator_A[0] *
    test1_X.Realderivator_CSTATE[0];
  _rtXdot->Realderivator_CSTATE[1] = 0.0;
  _rtXdot->Realderivator_CSTATE[0] += test1_P.Realderivator_A[1] *
    test1_X.Realderivator_CSTATE[1];
  _rtXdot->Realderivator_CSTATE[1] += test1_X.Realderivator_CSTATE[0];
  _rtXdot->Realderivator_CSTATE[0] += test1_B.Gain_b;

  /* Derivatives for TransferFcn: '<S2>/Real derivator1' */
  _rtXdot->Realderivator1_CSTATE[0] = 0.0;
  _rtXdot->Realderivator1_CSTATE[0] += test1_P.Realderivator1_A[0] *
    test1_X.Realderivator1_CSTATE[0];
  _rtXdot->Realderivator1_CSTATE[1] = 0.0;
  _rtXdot->Realderivator1_CSTATE[0] += test1_P.Realderivator1_A[1] *
    test1_X.Realderivator1_CSTATE[1];
  _rtXdot->Realderivator1_CSTATE[1] += test1_X.Realderivator1_CSTATE[0];
  _rtXdot->Realderivator1_CSTATE[0] += test1_B.Sum1;
}

/* Model initialize function */
void test1_initialize(void)
{
  /* Start for Enabled SubSystem: '<S3>/Average' */
  test1_DW.Average_MODE = false;

  /* End of Start for SubSystem: '<S3>/Average' */

  /* Start for S-Function (sldrtao): '<Root>/Analog Output' incorporates:
   *  Constant: '<Root>/Constant'
   */

  /* S-Function Block: <Root>/Analog Output */

  /* no initial value should be set */

  /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter = test1_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1, &test1_P.EncoderInput_Channels,
                   NULL, &parm);
  }

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator' */
  test1_X.Realderivator_CSTATE[0] = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator1' */
  test1_X.Realderivator1_CSTATE[0] = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator' */
  test1_X.Realderivator_CSTATE[1] = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator1' */
  test1_X.Realderivator1_CSTATE[1] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<S3>/Average' */
  /* InitializeConditions for DiscreteIntegrator: '<S4>/Discrete-Time Integrator' */
  test1_DW.DiscreteTimeIntegrator_DSTATE = test1_P.DiscreteTimeIntegrator_IC;

  /* SystemInitialize for DiscreteIntegrator: '<S4>/Discrete-Time Integrator' incorporates:
   *  Outport: '<S4>/Output'
   */
  test1_B.DiscreteTimeIntegrator = test1_P.Output_Y0;

  /* End of SystemInitialize for SubSystem: '<S3>/Average' */
}

/* Model terminate function */
void test1_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' incorporates:
   *  Constant: '<Root>/Constant'
   */

  /* S-Function Block: <Root>/Analog Output */

  /* no final value should be set */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  test1_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  test1_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  test1_initialize();
}

void MdlTerminate(void)
{
  test1_terminate();
}

/* Registration function */
RT_MODEL_test1_T *test1(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  test1_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)test1_M, 0,
                sizeof(RT_MODEL_test1_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&test1_M->solverInfo, &test1_M->Timing.simTimeStep);
    rtsiSetTPtr(&test1_M->solverInfo, &rtmGetTPtr(test1_M));
    rtsiSetStepSizePtr(&test1_M->solverInfo, &test1_M->Timing.stepSize0);
    rtsiSetdXPtr(&test1_M->solverInfo, &test1_M->derivs);
    rtsiSetContStatesPtr(&test1_M->solverInfo, (real_T **) &test1_M->contStates);
    rtsiSetNumContStatesPtr(&test1_M->solverInfo, &test1_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&test1_M->solverInfo,
      &test1_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&test1_M->solverInfo,
      &test1_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&test1_M->solverInfo,
      &test1_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&test1_M->solverInfo, (&rtmGetErrorStatus(test1_M)));
    rtsiSetRTModelPtr(&test1_M->solverInfo, test1_M);
  }

  rtsiSetSimTimeStep(&test1_M->solverInfo, MAJOR_TIME_STEP);
  test1_M->intgData.y = test1_M->odeY;
  test1_M->intgData.f[0] = test1_M->odeF[0];
  test1_M->intgData.f[1] = test1_M->odeF[1];
  test1_M->intgData.f[2] = test1_M->odeF[2];
  test1_M->contStates = ((real_T *) &test1_X);
  rtsiSetSolverData(&test1_M->solverInfo, (void *)&test1_M->intgData);
  rtsiSetSolverName(&test1_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = test1_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    test1_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    test1_M->Timing.sampleTimes = (&test1_M->Timing.sampleTimesArray[0]);
    test1_M->Timing.offsetTimes = (&test1_M->Timing.offsetTimesArray[0]);

    /* task periods */
    test1_M->Timing.sampleTimes[0] = (0.0);
    test1_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    test1_M->Timing.offsetTimes[0] = (0.0);
    test1_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(test1_M, &test1_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = test1_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    test1_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(test1_M, -1);
  test1_M->Timing.stepSize0 = 0.001;
  test1_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  test1_M->Sizes.checksums[0] = (1280322898U);
  test1_M->Sizes.checksums[1] = (408854203U);
  test1_M->Sizes.checksums[2] = (928714851U);
  test1_M->Sizes.checksums[3] = (2263427922U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[2];
    test1_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = (sysRanDType *)&test1_DW.Average_SubsysRanBC;
    rteiSetModelMappingInfoPtr(test1_M->extModeInfo,
      &test1_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(test1_M->extModeInfo, test1_M->Sizes.checksums);
    rteiSetTPtr(test1_M->extModeInfo, rtmGetTPtr(test1_M));
  }

  test1_M->solverInfoPtr = (&test1_M->solverInfo);
  test1_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&test1_M->solverInfo, 0.001);
  rtsiSetSolverMode(&test1_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  test1_M->blockIO = ((void *) &test1_B);
  (void) memset(((void *) &test1_B), 0,
                sizeof(B_test1_T));

  /* parameters */
  test1_M->defaultParam = ((real_T *)&test1_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &test1_X;
    test1_M->contStates = (x);
    (void) memset((void *)&test1_X, 0,
                  sizeof(X_test1_T));
  }

  /* states (dwork) */
  test1_M->dwork = ((void *) &test1_DW);
  (void) memset((void *)&test1_DW, 0,
                sizeof(DW_test1_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    test1_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 22;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  test1_M->Sizes.numContStates = (4);  /* Number of continuous states */
  test1_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  test1_M->Sizes.numY = (0);           /* Number of model outputs */
  test1_M->Sizes.numU = (0);           /* Number of model inputs */
  test1_M->Sizes.sysDirFeedThru = (0); /* The model is not direct feedthrough */
  test1_M->Sizes.numSampTimes = (2);   /* Number of sample times */
  test1_M->Sizes.numBlocks = (19);     /* Number of blocks */
  test1_M->Sizes.numBlockIO = (5);     /* Number of block outputs */
  test1_M->Sizes.numBlockPrms = (30);  /* Sum of parameter "widths" */
  return test1_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
