/*
 * FStest.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "FStest".
 *
 * Model version              : 1.6
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon May 10 13:06:13 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "FStest.h"
#include "FStest_private.h"
#include "FStest_dt.h"

/* options for Simulink Desktop Real-Time board 0 */
static double SLDRTBoardOptions0[] = {
  0.0,
  0.0,
  0.0,
  2.0,
  0.0,
};

/* list of Simulink Desktop Real-Time timers */
const int SLDRTTimerCount = 1;
const double SLDRTTimers[2] = {
  0.001, 0.0,
};

/* list of Simulink Desktop Real-Time boards */
const int SLDRTBoardCount = 1;
SLDRTBOARD SLDRTBoards[1] = {
  { "National_Instruments/PCI-6221", 4294967295U, 5, SLDRTBoardOptions0 },
};

/* Block signals (default storage) */
B_FStest_T FStest_B;

/* Continuous states */
X_FStest_T FStest_X;

/* Block states (default storage) */
DW_FStest_T FStest_DW;

/* Real-time model */
static RT_MODEL_FStest_T FStest_M_;
RT_MODEL_FStest_T *const FStest_M = &FStest_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 7;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  FStest_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  FStest_output();
  FStest_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  FStest_output();
  FStest_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model output function */
void FStest_output(void)
{
  /* local block i/o variables */
  real_T rtb_AnalogInput[2];
  real_T rtb_Sum;
  real_T rtb_Sum_a[6];
  real_T rtb_Sum_c[6];
  real_T rtb_Gain;
  real_T rtb_Gain1;
  real_T rtb_deg2rad;
  real_T tmp;
  real_T tmp_0;
  int32_T i;
  if (rtmIsMajorTimeStep(FStest_M)) {
    /* set solver stop time */
    if (!(FStest_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&FStest_M->solverInfo,
                            ((FStest_M->Timing.clockTickH0 + 1) *
        FStest_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&FStest_M->solverInfo, ((FStest_M->Timing.clockTick0
        + 1) * FStest_M->Timing.stepSize0 + FStest_M->Timing.clockTickH0 *
        FStest_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(FStest_M)) {
    FStest_M->Timing.t[0] = rtsiGetT(&FStest_M->solverInfo);
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(FStest_DW.Average_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(FStest_DW.StatespaceController_SubsysRanBC);
  if (rtmIsMajorTimeStep(FStest_M)) {
    /* S-Function (sldrtei): '<Root>/Encoder Input' */
    /* S-Function Block: <Root>/Encoder Input */
    {
      ENCODERINPARM parm;
      parm.quad = (QUADMODE) 2;
      parm.index = (INDEXPULSE) 0;
      parm.infilter = FStest_P.EncoderInput_InputFilter;
      RTBIO_DriverIO(0, ENCODERINPUT, IOREAD, 1, &FStest_P.EncoderInput_Channels,
                     &rtb_Sum, &parm);
    }

    /* S-Function (sldrtai): '<Root>/Analog Input' */
    /* S-Function Block: <Root>/Analog Input */
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) FStest_P.AnalogInput_RangeMode;
      parm.rangeidx = FStest_P.AnalogInput_VoltRange;
      RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2, FStest_P.AnalogInput_Channels,
                     &rtb_AnalogInput[0], &parm);
    }

    /* Gain: '<Root>/Gain' */
    FStest_B.Gain = FStest_P.sens.enc.pulse2deg * rtb_Sum;

    /* Sum: '<S1>/Sum' */
    rtb_Sum = rtb_AnalogInput[0] - rtb_AnalogInput[1];

    /* Gain: '<S1>/Gain' */
    FStest_B.Gain_l = FStest_P.sens.pot2.V2deg * rtb_Sum;
  }

  /* Clock: '<S4>/Clock' */
  rtb_deg2rad = FStest_M->Timing.t[0];

  /* Outputs for Enabled SubSystem: '<S4>/Average' incorporates:
   *  EnablePort: '<S5>/Enable'
   */
  if (rtmIsMajorTimeStep(FStest_M)) {
    /* Logic: '<S6>/AND' incorporates:
     *  Constant: '<S6>/Lower Limit'
     *  Constant: '<S6>/Upper Limit'
     *  RelationalOperator: '<S6>/Lower Test'
     *  RelationalOperator: '<S6>/Upper Test'
     */
    FStest_DW.Average_MODE = ((FStest_P.IntervalTest_lowlimit <= rtb_deg2rad) &&
      (rtb_deg2rad <= FStest_P.IntervalTest_uplimit));
  }

  if (FStest_DW.Average_MODE) {
    if (rtmIsMajorTimeStep(FStest_M)) {
      /* DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
      FStest_B.DiscreteTimeIntegrator = FStest_DW.DiscreteTimeIntegrator_DSTATE;
    }

    if (rtmIsMajorTimeStep(FStest_M)) {
      srUpdateBC(FStest_DW.Average_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<S4>/Average' */
  if (rtmIsMajorTimeStep(FStest_M)) {
    /* Sum: '<S1>/Sum1' */
    FStest_B.Sum1 = FStest_B.Gain_l - FStest_B.DiscreteTimeIntegrator;
  }

  /* Step: '<Root>/Step1' incorporates:
   *  Step: '<Root>/Step'
   */
  tmp_0 = FStest_M->Timing.t[0];
  if (tmp_0 < FStest_P.Step1_Time) {
    /* Step: '<Root>/Step1' */
    FStest_B.Step1 = FStest_P.Step1_Y0;
  } else {
    /* Step: '<Root>/Step1' */
    FStest_B.Step1 = FStest_P.Step1_YFinal;
  }

  /* End of Step: '<Root>/Step1' */
  if (rtmIsMajorTimeStep(FStest_M)) {
    /* SignalConversion generated from: '<S3>/Enable' */
    FStest_B.HiddenBuf_InsertedFor_StatespaceController_at_inport_6 =
      FStest_B.Step1;

    /* Outputs for Enabled SubSystem: '<Root>/State-space Controller' incorporates:
     *  EnablePort: '<S3>/Enable'
     */
    if (rtmIsMajorTimeStep(FStest_M)) {
      FStest_DW.StatespaceController_MODE =
        (FStest_B.HiddenBuf_InsertedFor_StatespaceController_at_inport_6 > 0.0);
    }

    /* End of Outputs for SubSystem: '<Root>/State-space Controller' */
  }

  /* Outputs for Enabled SubSystem: '<Root>/State-space Controller' incorporates:
   *  EnablePort: '<S3>/Enable'
   */
  if (FStest_DW.StatespaceController_MODE) {
    /* Step: '<Root>/Step' */
    if (tmp_0 < FStest_P.Step_Time) {
      tmp_0 = FStest_P.Step_Y0;
    } else {
      tmp_0 = FStest_P.Step_YFinal;
    }

    /* Gain: '<S3>/deg2rad' */
    rtb_deg2rad = FStest_P.deg2rad * tmp_0;

    /* Gain: '<S3>/State feedforward gain' */
    for (i = 0; i < 6; i++) {
      rtb_Sum_c[i] = FStest_P.FS_LQR.Nxa[i] * rtb_deg2rad;
    }

    /* End of Gain: '<S3>/State feedforward gain' */
    if (rtmIsMajorTimeStep(FStest_M)) {
      /* Gain: '<S3>/deg2rad1' */
      FStest_B.deg2rad1 = FStest_P.deg2rad * FStest_B.Gain;

      /* Gain: '<S3>/deg2rad2' */
      FStest_B.deg2rad2 = FStest_P.deg2rad * FStest_B.Sum1;
    }

    /* Gain: '<S3>/deg2rad3' incorporates:
     *  Gain: '<S2>/Gain'
     *  TransferFcn: '<S2>/Real derivator'
     */
    rtb_Gain = (FStest_P.Realderivator_C[0] * FStest_X.Realderivator_CSTATE[0] +
                FStest_P.Realderivator_C[1] * FStest_X.Realderivator_CSTATE[1]) *
      FStest_P.degs2rpm * FStest_P.rpm2rads;

    /* Gain: '<S3>/deg2rad4' incorporates:
     *  Gain: '<S2>/Gain1'
     *  TransferFcn: '<S2>/Real derivator1'
     */
    rtb_Gain1 = (FStest_P.Realderivator1_C[0] * FStest_X.Realderivator1_CSTATE[0]
                 + FStest_P.Realderivator1_C[1] *
                 FStest_X.Realderivator1_CSTATE[1]) * FStest_P.degs2rpm *
      FStest_P.deg2rad;

    /* Sum: '<S3>/Sum' incorporates:
     *  StateSpace: '<S3>/State-Space'
     */
    rtb_Sum_a[0] = rtb_Sum_c[0] - FStest_B.deg2rad1;
    rtb_Sum_a[1] = rtb_Sum_c[1] - FStest_B.deg2rad2;
    rtb_Sum_a[2] = rtb_Sum_c[2] - rtb_Gain;
    rtb_Sum_a[3] = rtb_Sum_c[3] - rtb_Gain1;
    rtb_Sum_a[4] = rtb_Sum_c[4] - (FStest_P.StateSpace_C[0] *
      FStest_X.StateSpace_CSTATE[0] + FStest_P.StateSpace_C[2] *
      FStest_X.StateSpace_CSTATE[1]);
    rtb_Sum_a[5] = rtb_Sum_c[5] - (FStest_P.StateSpace_C[1] *
      FStest_X.StateSpace_CSTATE[0] + FStest_P.StateSpace_C[3] *
      FStest_X.StateSpace_CSTATE[1]);

    /* Gain: '<S3>/State feedback gain' */
    tmp_0 = 0.0;
    for (i = 0; i < 6; i++) {
      /* Gain: '<S3>/State feedback gain' incorporates:
       *  Sum: '<S3>/Sum'
       */
      tmp_0 += FStest_P.FS_LQR.Kea[i] * rtb_Sum_a[i];
    }

    /* Switch: '<S3>/Switch' incorporates:
     *  Constant: '<Root>/Constant'
     *  Constant: '<S3>/Constant'
     *  Integrator: '<S3>/Integrator'
     */
    if (FStest_P.Constant_Value_e > FStest_P.Switch_Threshold) {
      tmp = FStest_X.Integrator_CSTATE;
    } else {
      tmp = FStest_P.Constant_Value;
    }

    /* End of Switch: '<S3>/Switch' */

    /* Sum: '<S3>/Sum1' incorporates:
     *  Gain: '<S3>/Input feedforward gain'
     *  Gain: '<S3>/State feedback gain'
     */
    FStest_B.Sum1_n = (FStest_P.FS_LQR.Nu * rtb_deg2rad + tmp_0) + tmp;
    if (rtmIsMajorTimeStep(FStest_M)) {
    }

    /* Gain: '<S3>/Ki' incorporates:
     *  Sum: '<S3>/Sum2'
     */
    FStest_B.Ki = (rtb_deg2rad - FStest_B.deg2rad1) * FStest_P.FS_LQR.Kei;

    /* Saturate: '<S3>/Saturation' */
    if (FStest_B.Sum1_n > FStest_P.Saturation_UpperSat) {
      /* Saturate: '<S3>/Saturation' */
      FStest_B.Saturation = FStest_P.Saturation_UpperSat;
    } else if (FStest_B.Sum1_n < FStest_P.Saturation_LowerSat) {
      /* Saturate: '<S3>/Saturation' */
      FStest_B.Saturation = FStest_P.Saturation_LowerSat;
    } else {
      /* Saturate: '<S3>/Saturation' */
      FStest_B.Saturation = FStest_B.Sum1_n;
    }

    /* End of Saturate: '<S3>/Saturation' */

    /* SignalConversion generated from: '<S3>/State-Space' */
    FStest_B.x[0] = FStest_B.deg2rad1;
    FStest_B.x[1] = FStest_B.deg2rad2;
    FStest_B.x[2] = rtb_Gain;
    FStest_B.x[3] = rtb_Gain1;
    if (rtmIsMajorTimeStep(FStest_M)) {
      srUpdateBC(FStest_DW.StatespaceController_SubsysRanBC);
    }
  }

  /* End of Outputs for SubSystem: '<Root>/State-space Controller' */
  if (rtmIsMajorTimeStep(FStest_M)) {
    /* S-Function (sldrtao): '<Root>/Analog Output' */
    /* S-Function Block: <Root>/Analog Output */
    {
      {
        ANALOGIOPARM parm;
        parm.mode = (RANGEMODE) FStest_P.AnalogOutput_RangeMode;
        parm.rangeidx = FStest_P.AnalogOutput_VoltRange;
        RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                       &FStest_P.AnalogOutput_Channels, ((real_T*)
          (&FStest_B.Saturation)), &parm);
      }
    }
  }
}

/* Model update function */
void FStest_update(void)
{
  /* Update for Enabled SubSystem: '<S4>/Average' incorporates:
   *  EnablePort: '<S5>/Enable'
   */
  if (FStest_DW.Average_MODE && rtmIsMajorTimeStep(FStest_M)) {
    /* Update for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
    FStest_DW.DiscreteTimeIntegrator_DSTATE +=
      FStest_P.DiscreteTimeIntegrator_gainval * FStest_B.Gain_l;
  }

  /* End of Update for SubSystem: '<S4>/Average' */
  if (rtmIsMajorTimeStep(FStest_M)) {
    rt_ertODEUpdateContinuousStates(&FStest_M->solverInfo);
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++FStest_M->Timing.clockTick0)) {
    ++FStest_M->Timing.clockTickH0;
  }

  FStest_M->Timing.t[0] = rtsiGetSolverStopTime(&FStest_M->solverInfo);

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++FStest_M->Timing.clockTick1)) {
      ++FStest_M->Timing.clockTickH1;
    }

    FStest_M->Timing.t[1] = FStest_M->Timing.clockTick1 *
      FStest_M->Timing.stepSize1 + FStest_M->Timing.clockTickH1 *
      FStest_M->Timing.stepSize1 * 4294967296.0;
  }
}

/* Derivatives for root system: '<Root>' */
void FStest_derivatives(void)
{
  XDot_FStest_T *_rtXdot;
  int_T ri;
  _rtXdot = ((XDot_FStest_T *) FStest_M->derivs);

  /* Derivatives for TransferFcn: '<S2>/Real derivator' */
  _rtXdot->Realderivator_CSTATE[0] = 0.0;
  _rtXdot->Realderivator_CSTATE[0] += FStest_P.Realderivator_A[0] *
    FStest_X.Realderivator_CSTATE[0];

  /* Derivatives for TransferFcn: '<S2>/Real derivator1' */
  _rtXdot->Realderivator1_CSTATE[0] = 0.0;
  _rtXdot->Realderivator1_CSTATE[0] += FStest_P.Realderivator1_A[0] *
    FStest_X.Realderivator1_CSTATE[0];

  /* Derivatives for TransferFcn: '<S2>/Real derivator' */
  _rtXdot->Realderivator_CSTATE[1] = 0.0;
  _rtXdot->Realderivator_CSTATE[0] += FStest_P.Realderivator_A[1] *
    FStest_X.Realderivator_CSTATE[1];

  /* Derivatives for TransferFcn: '<S2>/Real derivator1' */
  _rtXdot->Realderivator1_CSTATE[1] = 0.0;
  _rtXdot->Realderivator1_CSTATE[0] += FStest_P.Realderivator1_A[1] *
    FStest_X.Realderivator1_CSTATE[1];

  /* Derivatives for TransferFcn: '<S2>/Real derivator' */
  _rtXdot->Realderivator_CSTATE[1] += FStest_X.Realderivator_CSTATE[0];
  _rtXdot->Realderivator_CSTATE[0] += FStest_B.Gain;

  /* Derivatives for TransferFcn: '<S2>/Real derivator1' */
  _rtXdot->Realderivator1_CSTATE[1] += FStest_X.Realderivator1_CSTATE[0];
  _rtXdot->Realderivator1_CSTATE[0] += FStest_B.Sum1;

  /* Derivatives for Enabled SubSystem: '<Root>/State-space Controller' */
  if (FStest_DW.StatespaceController_MODE) {
    /* Derivatives for StateSpace: '<S3>/State-Space' */
    _rtXdot->StateSpace_CSTATE[0] = 0.0;
    _rtXdot->StateSpace_CSTATE[1] = 0.0;
    _rtXdot->StateSpace_CSTATE[0] += FStest_P.FS_LQR.Aq[0] *
      FStest_X.StateSpace_CSTATE[0];
    _rtXdot->StateSpace_CSTATE[1] += FStest_P.FS_LQR.Aq[1] *
      FStest_X.StateSpace_CSTATE[0];
    _rtXdot->StateSpace_CSTATE[0] += FStest_P.FS_LQR.Aq[2] *
      FStest_X.StateSpace_CSTATE[1];
    _rtXdot->StateSpace_CSTATE[1] += FStest_P.FS_LQR.Aq[3] *
      FStest_X.StateSpace_CSTATE[1];
    for (ri = 0; ri < 2; ri++) {
      _rtXdot->StateSpace_CSTATE[ri] += FStest_P.FS_LQR.Bq[ri] * FStest_B.x[0];
      _rtXdot->StateSpace_CSTATE[ri] += FStest_P.FS_LQR.Bq[ri + 2] * FStest_B.x
        [1];
      _rtXdot->StateSpace_CSTATE[ri] += FStest_P.FS_LQR.Bq[ri + 4] * FStest_B.x
        [2];
      _rtXdot->StateSpace_CSTATE[ri] += FStest_P.FS_LQR.Bq[ri + 6] * FStest_B.x
        [3];
    }

    /* End of Derivatives for StateSpace: '<S3>/State-Space' */

    /* Derivatives for Integrator: '<S3>/Integrator' */
    _rtXdot->Integrator_CSTATE = FStest_B.Ki;
  } else {
    {
      real_T *dx;
      int_T i;
      dx = &(((XDot_FStest_T *) FStest_M->derivs)->StateSpace_CSTATE[0]);
      for (i=0; i < 3; i++) {
        dx[i] = 0.0;
      }
    }
  }

  /* End of Derivatives for SubSystem: '<Root>/State-space Controller' */
}

/* Model initialize function */
void FStest_initialize(void)
{
  /* Start for Enabled SubSystem: '<S4>/Average' */
  FStest_DW.Average_MODE = false;

  /* End of Start for SubSystem: '<S4>/Average' */

  /* Start for Enabled SubSystem: '<Root>/State-space Controller' */
  FStest_DW.StatespaceController_MODE = false;

  /* End of Start for SubSystem: '<Root>/State-space Controller' */

  /* Start for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) FStest_P.AnalogOutput_RangeMode;
      parm.rangeidx = FStest_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &FStest_P.AnalogOutput_Channels,
                     &FStest_P.AnalogOutput_InitialValue, &parm);
    }
  }

  /* InitializeConditions for S-Function (sldrtei): '<Root>/Encoder Input' */

  /* S-Function Block: <Root>/Encoder Input */
  {
    ENCODERINPARM parm;
    parm.quad = (QUADMODE) 2;
    parm.index = (INDEXPULSE) 0;
    parm.infilter = FStest_P.EncoderInput_InputFilter;
    RTBIO_DriverIO(0, ENCODERINPUT, IORESET, 1, &FStest_P.EncoderInput_Channels,
                   NULL, &parm);
  }

  /* SystemInitialize for Enabled SubSystem: '<S4>/Average' */
  /* InitializeConditions for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' */
  FStest_DW.DiscreteTimeIntegrator_DSTATE = FStest_P.DiscreteTimeIntegrator_IC;

  /* SystemInitialize for DiscreteIntegrator: '<S5>/Discrete-Time Integrator' incorporates:
   *  Outport: '<S5>/Output'
   */
  FStest_B.DiscreteTimeIntegrator = FStest_P.Output_Y0;

  /* End of SystemInitialize for SubSystem: '<S4>/Average' */

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator' */
  FStest_X.Realderivator_CSTATE[0] = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator1' */
  FStest_X.Realderivator1_CSTATE[0] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<Root>/State-space Controller' */
  /* InitializeConditions for StateSpace: '<S3>/State-Space' */
  FStest_X.StateSpace_CSTATE[0] = FStest_P.StateSpace_InitialCondition;

  /* End of SystemInitialize for SubSystem: '<Root>/State-space Controller' */

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator' */
  FStest_X.Realderivator_CSTATE[1] = 0.0;

  /* InitializeConditions for TransferFcn: '<S2>/Real derivator1' */
  FStest_X.Realderivator1_CSTATE[1] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<Root>/State-space Controller' */
  /* InitializeConditions for StateSpace: '<S3>/State-Space' */
  FStest_X.StateSpace_CSTATE[1] = FStest_P.StateSpace_InitialCondition;

  /* InitializeConditions for Integrator: '<S3>/Integrator' */
  FStest_X.Integrator_CSTATE = FStest_P.Integrator_IC;

  /* SystemInitialize for Saturate: '<S3>/Saturation' incorporates:
   *  Outport: '<S3>/u[V]'
   */
  FStest_B.Saturation = FStest_P.uV_Y0;

  /* End of SystemInitialize for SubSystem: '<Root>/State-space Controller' */
}

/* Model terminate function */
void FStest_terminate(void)
{
  /* Terminate for S-Function (sldrtao): '<Root>/Analog Output' */

  /* S-Function Block: <Root>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE) FStest_P.AnalogOutput_RangeMode;
      parm.rangeidx = FStest_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &FStest_P.AnalogOutput_Channels,
                     &FStest_P.AnalogOutput_FinalValue, &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/

/* Solver interface called by GRT_Main */
#ifndef USE_GENERATED_SOLVER

void rt_ODECreateIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEDestroyIntegrationData(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

void rt_ODEUpdateContinuousStates(RTWSolverInfo *si)
{
  UNUSED_PARAMETER(si);
  return;
}                                      /* do nothing */

#endif

void MdlOutputs(int_T tid)
{
  FStest_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  FStest_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  FStest_initialize();
}

void MdlTerminate(void)
{
  FStest_terminate();
}

/* Registration function */
RT_MODEL_FStest_T *FStest(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* non-finite (run-time) assignments */
  FStest_P.EncoderInput_InputFilter = rtInf;

  /* initialize real-time model */
  (void) memset((void *)FStest_M, 0,
                sizeof(RT_MODEL_FStest_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&FStest_M->solverInfo, &FStest_M->Timing.simTimeStep);
    rtsiSetTPtr(&FStest_M->solverInfo, &rtmGetTPtr(FStest_M));
    rtsiSetStepSizePtr(&FStest_M->solverInfo, &FStest_M->Timing.stepSize0);
    rtsiSetdXPtr(&FStest_M->solverInfo, &FStest_M->derivs);
    rtsiSetContStatesPtr(&FStest_M->solverInfo, (real_T **)
                         &FStest_M->contStates);
    rtsiSetNumContStatesPtr(&FStest_M->solverInfo,
      &FStest_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&FStest_M->solverInfo,
      &FStest_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&FStest_M->solverInfo,
      &FStest_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&FStest_M->solverInfo,
      &FStest_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&FStest_M->solverInfo, (&rtmGetErrorStatus(FStest_M)));
    rtsiSetRTModelPtr(&FStest_M->solverInfo, FStest_M);
  }

  rtsiSetSimTimeStep(&FStest_M->solverInfo, MAJOR_TIME_STEP);
  FStest_M->intgData.y = FStest_M->odeY;
  FStest_M->intgData.f[0] = FStest_M->odeF[0];
  FStest_M->intgData.f[1] = FStest_M->odeF[1];
  FStest_M->intgData.f[2] = FStest_M->odeF[2];
  FStest_M->contStates = ((real_T *) &FStest_X);
  rtsiSetSolverData(&FStest_M->solverInfo, (void *)&FStest_M->intgData);
  rtsiSetSolverName(&FStest_M->solverInfo,"ode3");

  /* Initialize timing info */
  {
    int_T *mdlTsMap = FStest_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    FStest_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    FStest_M->Timing.sampleTimes = (&FStest_M->Timing.sampleTimesArray[0]);
    FStest_M->Timing.offsetTimes = (&FStest_M->Timing.offsetTimesArray[0]);

    /* task periods */
    FStest_M->Timing.sampleTimes[0] = (0.0);
    FStest_M->Timing.sampleTimes[1] = (0.001);

    /* task offsets */
    FStest_M->Timing.offsetTimes[0] = (0.0);
    FStest_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(FStest_M, &FStest_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = FStest_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    FStest_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(FStest_M, 4.0);
  FStest_M->Timing.stepSize0 = 0.001;
  FStest_M->Timing.stepSize1 = 0.001;

  /* External mode info */
  FStest_M->Sizes.checksums[0] = (3681810886U);
  FStest_M->Sizes.checksums[1] = (866045707U);
  FStest_M->Sizes.checksums[2] = (2080334657U);
  FStest_M->Sizes.checksums[3] = (2804023297U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[3];
    FStest_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = (sysRanDType *)&FStest_DW.Average_SubsysRanBC;
    systemRan[2] = (sysRanDType *)&FStest_DW.StatespaceController_SubsysRanBC;
    rteiSetModelMappingInfoPtr(FStest_M->extModeInfo,
      &FStest_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(FStest_M->extModeInfo, FStest_M->Sizes.checksums);
    rteiSetTPtr(FStest_M->extModeInfo, rtmGetTPtr(FStest_M));
  }

  FStest_M->solverInfoPtr = (&FStest_M->solverInfo);
  FStest_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&FStest_M->solverInfo, 0.001);
  rtsiSetSolverMode(&FStest_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  FStest_M->blockIO = ((void *) &FStest_B);
  (void) memset(((void *) &FStest_B), 0,
                sizeof(B_FStest_T));

  /* parameters */
  FStest_M->defaultParam = ((real_T *)&FStest_P);

  /* states (continuous) */
  {
    real_T *x = (real_T *) &FStest_X;
    FStest_M->contStates = (x);
    (void) memset((void *)&FStest_X, 0,
                  sizeof(X_FStest_T));
  }

  /* states (dwork) */
  FStest_M->dwork = ((void *) &FStest_DW);
  (void) memset((void *)&FStest_DW, 0,
                sizeof(DW_FStest_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    FStest_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 23;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Initialize Sizes */
  FStest_M->Sizes.numContStates = (7); /* Number of continuous states */
  FStest_M->Sizes.numPeriodicContStates = (0);
                                      /* Number of periodic continuous states */
  FStest_M->Sizes.numY = (0);          /* Number of model outputs */
  FStest_M->Sizes.numU = (0);          /* Number of model inputs */
  FStest_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  FStest_M->Sizes.numSampTimes = (2);  /* Number of sample times */
  FStest_M->Sizes.numBlocks = (44);    /* Number of blocks */
  FStest_M->Sizes.numBlockIO = (13);   /* Number of block outputs */
  FStest_M->Sizes.numBlockPrms = (53); /* Sum of parameter "widths" */
  return FStest_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
