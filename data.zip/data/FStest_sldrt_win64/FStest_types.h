/*
 * FStest_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "FStest".
 *
 * Model version              : 1.6
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon May 10 13:06:13 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_FStest_types_h_
#define RTW_HEADER_FStest_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_
#define DEFINED_TYPEDEF_FOR_struct_vHPMdAr9HfDgWNbG6U3SfC_

typedef struct {
  real_T Rs;
} struct_vHPMdAr9HfDgWNbG6U3SfC;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_
#define DEFINED_TYPEDEF_FOR_struct_L7PNJsBgXqfoUC1iyFkLDE_

typedef struct {
  real_T ppr;
  real_T pulse2deg;
  real_T pulse2rad;
  real_T deg2pulse;
  real_T rad2pulse;
  real_T T_s;
  real_T q;
} struct_L7PNJsBgXqfoUC1iyFkLDE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_
#define DEFINED_TYPEDEF_FOR_struct_DqRrFctOcoTwJhkxMXTGZG_

typedef struct {
  real_T R;
  real_T V;
  real_T th_deg;
  real_T th;
} struct_DqRrFctOcoTwJhkxMXTGZG;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_
#define DEFINED_TYPEDEF_FOR_struct_t4jfYKvXkqvqbOrnXV9flF_

typedef struct {
  struct_DqRrFctOcoTwJhkxMXTGZG range;
  real_T deg2V;
  real_T rad2V;
  real_T V2deg;
  real_T V2rad;
} struct_t4jfYKvXkqvqbOrnXV9flF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_i7ZlkOl9k9qbhxQhPErSIE_
#define DEFINED_TYPEDEF_FOR_struct_i7ZlkOl9k9qbhxQhPErSIE_

typedef struct {
  real_T var;
} struct_i7ZlkOl9k9qbhxQhPErSIE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_nhbocl71hD6FRzHagkwJFB_
#define DEFINED_TYPEDEF_FOR_struct_nhbocl71hD6FRzHagkwJFB_

typedef struct {
  struct_DqRrFctOcoTwJhkxMXTGZG range;
  real_T deg2V;
  real_T rad2V;
  real_T V2deg;
  real_T V2rad;
  struct_i7ZlkOl9k9qbhxQhPErSIE noise;
} struct_nhbocl71hD6FRzHagkwJFB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_2UetnoeKRPLjw6pbKQs9iF_
#define DEFINED_TYPEDEF_FOR_struct_2UetnoeKRPLjw6pbKQs9iF_

typedef struct {
  struct_vHPMdAr9HfDgWNbG6U3SfC curr;
  struct_L7PNJsBgXqfoUC1iyFkLDE enc;
  struct_t4jfYKvXkqvqbOrnXV9flF pot1;
  struct_nhbocl71hD6FRzHagkwJFB pot2;
} struct_2UetnoeKRPLjw6pbKQs9iF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_SsqUAX3vmEAO9YAgi1rlE_
#define DEFINED_TYPEDEF_FOR_struct_SsqUAX3vmEAO9YAgi1rlE_

typedef struct {
  real_T wc;
  real_T d;
  real_T NUM[2];
  real_T DEN[3];
} struct_SsqUAX3vmEAO9YAgi1rlE;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_ZjvBtcG87DPfGhlaWps51D_
#define DEFINED_TYPEDEF_FOR_struct_ZjvBtcG87DPfGhlaWps51D_

typedef struct {
  real_T w0;
  real_T q22;
  real_T Aq_p[4];
  real_T Bq_p[2];
  real_T Cq_p[2];
  real_T Dq_p;
  real_T Aq[4];
  real_T Bq[8];
  real_T Cq[8];
  real_T Dq[16];
  real_T Aa[36];
  real_T Ba[6];
  real_T Ca[6];
  real_T Da;
  real_T Qa001[36];
  real_T Na[7];
  real_T Ra;
  real_T Ka[6];
  real_T Nxa[6];
  real_T Nu;
  real_T Qa1[36];
  real_T Qa100[36];
  real_T Ae[49];
  real_T Be[7];
  real_T Ce[7];
  real_T De;
  real_T qi;
  real_T Qe[49];
  real_T Re;
  real_T Ke[7];
  real_T Kei;
  real_T Kea[6];
} struct_ZjvBtcG87DPfGhlaWps51D;

#endif

/* Parameters (default storage) */
typedef struct P_FStest_T_ P_FStest_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_FStest_T RT_MODEL_FStest_T;

#endif                                 /* RTW_HEADER_FStest_types_h_ */
