/*
 * FStest_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "FStest".
 *
 * Model version              : 1.6
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Mon May 10 13:06:13 2021
 *
 * Target selection: sldrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "FStest.h"
#include "FStest_private.h"

/* Block parameters (default storage) */
P_FStest_T FStest_P = {
  /* Variable: FS_LQR
   * Referenced by:
   *   '<S3>/Input feedforward gain'
   *   '<S3>/Ki'
   *   '<S3>/State feedback gain'
   *   '<S3>/State feedforward gain'
   *   '<S3>/State-Space'
   */
  {
    48.201161885200982,
    100.0,

    { 0.0, -2323.352007083352, 1.0, 0.0 },

    { 0.0, 1.0 },

    { 23233.520070833518, 0.0 },
    0.0,

    { 0.0, -2323.352007083352, 1.0, 0.0 },

    { 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0 },

    { 0.0, 23233.520070833518, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 11.459155902616464, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1509.6819570274638,
      -2329.6819570274638, 0.0, 1.0, 1.0, 0.0, -5.0854834240235958,
      3.29976913830931, 0.0, 0.0, 0.0, 1.0, 0.0, -1.7857142857142858, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, -2323.352007083352, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0
    },

    { 0.0, 0.0, 27.270997413322117, -27.270997413322117, 0.0, 0.0 },

    { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
    0.0,

    { 131.31225400046975, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 539796454.8818239, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 1.0, -0.0, -0.0, 0.0, -0.0, -0.0, 0.0 },
    0.01,

    { 114.59155902616371, 10.365355633789379, 4.037630065333186,
      1.4530963804574821, 15192.451455018469, -364.67988176434852 },

    { 1.0, -0.0, -0.0, 0.0, -0.0, -0.0 },
    0.0,

    { 131.31225400046975, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 5397964.54881824, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 131.31225400046975, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 539796454.8818239, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 1509.6819570274638, -2329.6819570274638, 0.0, 1.0, 0.0, 1.0, 0.0,
      -5.0854834240235958, 3.29976913830931, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0,
      -1.7857142857142858, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      -2323.352007083352, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0 },

    { 0.0, 0.0, 0.0, 27.270997413322117, -27.270997413322117, 0.0, 0.0 },

    { 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
    0.0,
    10.0,

    { 10.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 131.31225400046975, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      539796454.8818239, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },
    0.01,

    { 31.622776601683125, 116.59864222630773, -120.8870143130475,
      6.8011951169641627, 2.8101761190935166, 37038.279437378071,
      -4758.4730068943536 },
    31.622776601683125,

    { 116.59864222630773, -120.8870143130475, 6.8011951169641627,
      2.8101761190935166, 37038.279437378071, -4758.4730068943536 }
  },

  /* Variable: sens
   * Referenced by:
   *   '<Root>/Gain'
   *   '<S1>/Gain'
   */
  {
    {
      0.5
    },

    {
      4096.0,
      0.087890625,
      0.0015339807878856412,
      11.377777777777778,
      651.89864690440334,
      0.001,
      0.087890625
    },

    {
      {
        10000.0,
        5.0,
        345.0,
        6.0213859193804371
      },
      0.014492753623188406,
      0.83037361613162786,
      69.0,
      1.2042771838760873
    },

    {
      {
        10000.0,
        5.0,
        340.0,
        5.9341194567807207
      },
      0.014705882352941176,
      0.84258499283944588,
      68.0,
      1.1868238913561442,

      {
        3.5e-7
      }
    }
  },

  /* Variable: deg2rad
   * Referenced by:
   *   '<S3>/deg2rad'
   *   '<S3>/deg2rad1'
   *   '<S3>/deg2rad2'
   *   '<S3>/deg2rad4'
   */
  0.017453292519943295,

  /* Variable: degs2rpm
   * Referenced by:
   *   '<S2>/Gain'
   *   '<S2>/Gain1'
   */
  0.16666666666666666,

  /* Variable: rpm2rads
   * Referenced by: '<S3>/deg2rad3'
   */
  0.10471975511965977,

  /* Mask Parameter: AnalogOutput_FinalValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_InitialValue
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: EncoderInput_InputFilter
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: EncoderInput_MaxMissedTicks
   * Referenced by: '<Root>/Encoder Input'
   */
  10.0,

  /* Mask Parameter: AnalogInput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Input'
   */
  10.0,

  /* Mask Parameter: AnalogOutput_MaxMissedTicks
   * Referenced by: '<Root>/Analog Output'
   */
  10.0,

  /* Mask Parameter: EncoderInput_YieldWhenWaiting
   * Referenced by: '<Root>/Encoder Input'
   */
  0.0,

  /* Mask Parameter: AnalogInput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Input'
   */
  0.0,

  /* Mask Parameter: AnalogOutput_YieldWhenWaiting
   * Referenced by: '<Root>/Analog Output'
   */
  0.0,

  /* Mask Parameter: IntervalTest_lowlimit
   * Referenced by: '<S6>/Lower Limit'
   */
  0.2,

  /* Mask Parameter: IntervalTest_uplimit
   * Referenced by: '<S6>/Upper Limit'
   */
  0.7,

  /* Mask Parameter: EncoderInput_Channels
   * Referenced by: '<Root>/Encoder Input'
   */
  0,

  /* Mask Parameter: AnalogInput_Channels
   * Referenced by: '<Root>/Analog Input'
   */
  { 2, 3 },

  /* Mask Parameter: AnalogOutput_Channels
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_RangeMode
   * Referenced by: '<Root>/Analog Input'
   */
  0,

  /* Mask Parameter: AnalogOutput_RangeMode
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Mask Parameter: AnalogInput_VoltRange
   * Referenced by: '<Root>/Analog Input'
   */
  1,

  /* Mask Parameter: AnalogOutput_VoltRange
   * Referenced by: '<Root>/Analog Output'
   */
  0,

  /* Computed Parameter: Output_Y0
   * Referenced by: '<S5>/Output'
   */
  0.0,

  /* Computed Parameter: DiscreteTimeIntegrator_gainval
   * Referenced by: '<S5>/Discrete-Time Integrator'
   */
  0.0020000000000000005,

  /* Expression: 0
   * Referenced by: '<S5>/Discrete-Time Integrator'
   */
  0.0,

  /* Computed Parameter: uV_Y0
   * Referenced by: '<S3>/u[V]'
   */
  0.0,

  /* Expression: eye(2)
   * Referenced by: '<S3>/State-Space'
   */
  { 1.0, 0.0, 0.0, 1.0 },

  /* Expression: 0
   * Referenced by: '<S3>/State-Space'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Integrator'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Constant'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S3>/Switch'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<S3>/Saturation'
   */
  10.0,

  /* Expression: -10
   * Referenced by: '<S3>/Saturation'
   */
  -10.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step'
   */
  0.0,

  /* Expression: 50
   * Referenced by: '<Root>/Step'
   */
  50.0,

  /* Computed Parameter: Realderivator_A
   * Referenced by: '<S2>/Real derivator'
   */
  { -444.2882938158366, -98696.044010893587 },

  /* Computed Parameter: Realderivator_C
   * Referenced by: '<S2>/Real derivator'
   */
  { 98696.044010893587, 0.0 },

  /* Computed Parameter: Realderivator1_A
   * Referenced by: '<S2>/Real derivator1'
   */
  { -444.2882938158366, -98696.044010893587 },

  /* Computed Parameter: Realderivator1_C
   * Referenced by: '<S2>/Real derivator1'
   */
  { 98696.044010893587, 0.0 },

  /* Expression: 1
   * Referenced by: '<Root>/Constant'
   */
  1.0,

  /* Expression: 0.7
   * Referenced by: '<Root>/Step1'
   */
  0.7,

  /* Expression: 0
   * Referenced by: '<Root>/Step1'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Step1'
   */
  1.0
};
